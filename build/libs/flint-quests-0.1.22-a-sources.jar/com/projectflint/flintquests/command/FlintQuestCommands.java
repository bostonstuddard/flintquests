package com.projectflint.flintquests.command;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.projectflint.flintquests.config.ConfigManager;
import com.projectflint.flintquests.data.CategoryRepository;
import com.projectflint.flintquests.data.QuestDefinition;
import com.projectflint.flintquests.data.QuestRepository;
import com.projectflint.flintquests.engine.QuestEngine;
import com.projectflint.flintquests.progress.ProgressManager;
import com.projectflint.flintquests.progress.QuestProgress;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.List;

public final class FlintQuestCommands {
	private FlintQuestCommands() {
	}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
				class_2170.method_9247("flintquests")
						.requires(source -> ConfigManager.devEnvironmentAvailable())
						.executes(context -> help(context.getSource().method_9207()))
						.then(class_2170.method_9247("list")
								.executes(context -> list(context.getSource().method_9207())))
						.then(class_2170.method_9247("progress")
								.executes(context -> progress(context.getSource().method_9207())))
						.then(class_2170.method_9247("reload")
								.requires(class_2170.method_71774(class_2170.field_31839))
								.executes(context -> reload(context.getSource().method_9207())))
						.then(class_2170.method_9247("validate")
								.requires(class_2170.method_71774(class_2170.field_31839))
								.executes(context -> validate(context.getSource().method_9207())))
						.then(class_2170.method_9247("editing")
								.requires(class_2170.method_71774(class_2170.field_31839))
								.then(class_2170.method_9244("enabled", BoolArgumentType.bool())
										.executes(context -> editing(
												context.getSource().method_9207(),
												BoolArgumentType.getBool(context, "enabled")
										))))
						.then(class_2170.method_9247("reset")
								.requires(class_2170.method_71774(class_2170.field_31839))
								.executes(context -> reset(context.getSource().method_9207())))
		));
	}

	private static int help(class_3222 player) {
		player.method_7353(class_2561.method_43470("Flint Quests commands: list, progress, reload, validate, editing <true|false>, reset"), false);
		return 1;
	}

	private static int list(class_3222 player) {
		List<QuestDefinition> quests = QuestRepository.all();
		player.method_7353(class_2561.method_43470("Flint Quests: " + quests.size() + " loaded quest(s)."), false);
		for (QuestDefinition quest : quests) {
			String state = QuestEngine.isCompleted(player, quest.id) ? "[COMPLETE] " : "[ ] ";
			player.method_7353(class_2561.method_43470(state + quest.id + " - " + quest.title), false);
		}
		return quests.size();
	}

	private static int progress(class_3222 player) {
		int shown = 0;
		for (QuestDefinition quest : QuestRepository.all()) {
			QuestProgress progress = QuestEngine.progress(player, quest.id);
			if (progress == null) continue;
			player.method_7353(class_2561.method_43470(
					(progress.complete ? "[COMPLETE] " : "[ACTIVE] ") + quest.title
			), false);
			shown++;
		}
		if (shown == 0) player.method_7353(class_2561.method_43470("No Flint Quests progress recorded yet."), false);
		return shown;
	}

	private static int reload(class_3222 player) {
		ConfigManager.load();
		QuestRepository.load();
		CategoryRepository.load();
		player.method_7353(class_2561.method_43470("Reloaded Flint Quests config, categories, and quest definitions."), false);
		return 1;
	}

	private static int validate(class_3222 player) {
		List<String> problems = QuestRepository.validate();
		if (problems.isEmpty()) {
			player.method_7353(class_2561.method_43470("Flint Quests validation passed."), false);
			return 1;
		}
		player.method_7353(class_2561.method_43470("Flint Quests validation found " + problems.size() + " issue(s):"), false);
		for (String problem : problems) player.method_7353(class_2561.method_43470(problem), false);
		return problems.stream().anyMatch(value -> value.startsWith("ERROR")) ? 0 : 1;
	}

	private static int editing(class_3222 player, boolean enabled) {
		ConfigManager.get().questEditing = enabled;
		ConfigManager.save();
		player.method_7353(class_2561.method_43470("Flint Quests editing = " + enabled), false);
		return 1;
	}

	private static int reset(class_3222 player) {
		ProgressManager.reset(player);
		player.method_7353(class_2561.method_43470("Your Flint Quests progress was reset."), false);
		return 1;
	}
}
