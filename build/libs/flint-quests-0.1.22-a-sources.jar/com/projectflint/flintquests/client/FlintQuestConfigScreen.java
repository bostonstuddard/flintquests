package com.projectflint.flintquests.client;

import com.projectflint.flintquests.config.ConfigManager;
import com.projectflint.flintquests.data.CategoryRepository;
import com.projectflint.flintquests.data.QuestRepository;
import com.projectflint.flintquests.export.QuestBundleExporter;
import com.projectflint.flintquests.export.QuestDataZipTransfer;
import com.projectflint.flintquests.theme.QuestTheme;
import com.projectflint.flintquests.theme.QuestThemeManager;
import java.nio.file.Path;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Settings screen used both by Mod Menu and the in-book Settings button. */
public final class FlintQuestConfigScreen extends class_437 {
    private final class_437 parent;
    private String exportStatus = "";
    private boolean exportFailed;

    public FlintQuestConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Flint Quests Settings"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        ConfigManager.load();
        QuestThemeManager.reload();

        int center = field_22789 / 2;
        int buttonWidth = Math.min(300, Math.max(190, field_22789 - 24));
        int left = center - buttonWidth / 2;
        int top = 50;
        int step = 24;
        int row = 0;

        method_37063(class_4185.method_46430(announceLabel(), button -> {
            ConfigManager.get().announceQuestCompletion = !ConfigManager.get().announceQuestCompletion;
            ConfigManager.save();
            button.method_25355(announceLabel());
        }).method_46434(left, top + row++ * step, buttonWidth, 19).method_46431());

        if (!ConfigManager.isPlayerBundle()) {
            method_37063(class_4185.method_46430(themeLabel(), button -> {
                QuestThemeManager.cycle();
                button.method_25355(themeLabel());
            }).method_46434(left, top + row++ * step, buttonWidth, 19).method_46431());

            method_37063(class_4185.method_46430(class_2561.method_43470("Open Theme Folder"), button -> {
                exportFailed = false;
                try {
                    QuestThemeManager.openThemeDirectory();
                    exportStatus = "Opened config/flintquests/themes";
                } catch (Exception exception) {
                    exportFailed = true;
                    exportStatus = "Could not open themes: " + compactMessage(exception);
                }
            }).method_46434(left, top + row++ * step, buttonWidth, 19).method_46431());
        }

        if (ConfigManager.devEnvironmentAvailable()) {
            method_37063(class_4185.method_46430(editingLabel(), button -> {
                ConfigManager.get().questEditing = !ConfigManager.get().questEditing;
                ConfigManager.save();
                button.method_25355(editingLabel());
            }).method_46434(left, top + row++ * step, buttonWidth, 19).method_46431());

            int gap = 6;
            int half = (buttonWidth - gap) / 2;
            int rowY = top + row++ * step;
            method_37063(class_4185.method_46430(class_2561.method_43470("Build Nestable .jar"), button -> {
                button.field_22763 = false;
                exportStatus = "Building quest-pack jar...";
                exportFailed = false;
                try {
                    Path built = QuestBundleExporter.buildNestableJar();
                    exportStatus = "Built: " + built.getFileName();
                } catch (Exception exception) {
                    exportFailed = true;
                    exportStatus = "Export failed: " + compactMessage(exception);
                } finally {
                    button.field_22763 = true;
                }
            }).method_46434(left, rowY, half, 19).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("Open Built Jars"), button -> {
                exportFailed = false;
                try {
                    QuestBundleExporter.openExportDirectory();
                    exportStatus = "Opened flintquests-exports";
                } catch (Exception exception) {
                    exportFailed = true;
                    exportStatus = "Could not open exports: " + compactMessage(exception);
                }
            }).method_46434(left + half + gap, rowY, half, 19).method_46431());

            rowY = top + row++ * step;
            method_37063(class_4185.method_46430(class_2561.method_43470("Export Quest Data ZIP"), button -> {
                exportFailed = false;
                try {
                    Path built = QuestDataZipTransfer.exportDataZip();
                    exportStatus = "Exported: " + built.getFileName();
                } catch (Exception exception) {
                    exportFailed = true;
                    exportStatus = "Data export failed: " + compactMessage(exception);
                }
            }).method_46434(left, rowY, half, 19).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("Import Quest Data ZIP"), button -> {
                exportFailed = false;
                try {
                    Path backup = QuestDataZipTransfer.chooseAndImportDataZip();
                    if (backup == null) {
                        exportStatus = "Import cancelled";
                    } else {
                        QuestRepository.load();
                        CategoryRepository.load();
                        QuestThemeManager.reload();
                        exportStatus = "Imported quest data. Backup: " + backup.getFileName();
                    }
                } catch (Exception exception) {
                    exportFailed = true;
                    exportStatus = "Data import failed: " + compactMessage(exception);
                }
            }).method_46434(left + half + gap, rowY, half, 19).method_46431());

            method_37063(class_4185.method_46430(class_2561.method_43470("Open Quest Data ZIP Folder"), button -> {
                exportFailed = false;
                try {
                    QuestDataZipTransfer.openTransferDirectory();
                    exportStatus = "Opened flintquests-exports/quest-data";
                } catch (Exception exception) {
                    exportFailed = true;
                    exportStatus = "Could not open quest-data folder: " + compactMessage(exception);
                }
            }).method_46434(left, top + row++ * step, buttonWidth, 19).method_46431());

            method_37063(class_4185.method_46430(class_2561.method_43470("Developer Environment: ON (disable)"), button -> {
                ConfigManager.get().devEnvironment = false;
                ConfigManager.get().questEditing = false;
                ConfigManager.save();
                field_22787.method_1507(new FlintQuestConfigScreen(parent));
            }).method_46434(left, top + row++ * step, buttonWidth, 19).method_46431());
        }

        int doneY = Math.min(field_22790 - 24, top + row * step + 6);
        method_37063(class_4185.method_46430(class_2561.method_43470("Done"), button -> method_25419())
                .method_46434(center - 50, doneY, 100, 19).method_46431());
    }

    private class_2561 editingLabel() {
        return class_2561.method_43470("Quest Editing: " + enabled(ConfigManager.get().questEditing));
    }

    private class_2561 announceLabel() {
        return class_2561.method_43470("Quest Completion Popups: " + enabled(ConfigManager.get().announceQuestCompletion));
    }

    private class_2561 themeLabel() {
        return class_2561.method_43470("Theme: " + QuestThemeManager.activeName() + "  (click to cycle)");
    }

    private String enabled(boolean value) {
        return value ? "ON" : "OFF";
    }

    public void refreshEditingMode() {
        method_41843();
    }

    private String compactMessage(Exception exception) {
        String message = exception.getMessage();
        if (message == null || message.isBlank()) return exception.getClass().getSimpleName();
        return message.length() > 92 ? message.substring(0, 89) + "..." : message;
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        QuestTheme theme = QuestThemeManager.current();
        graphics.method_25294(0, 0, field_22789, field_22790, theme.backgroundColor());
        graphics.method_27534(field_22793, field_22785, field_22789 / 2, 18, theme.titleTextColor());
        if (ConfigManager.isPlayerBundle()) {
            graphics.method_27534(field_22793,
                    class_2561.method_43470("Player quest-pack distribution — authoring tools are disabled"),
                    field_22789 / 2, 32, theme.mutedTextColor());
        } else if (ConfigManager.devEnvironmentAvailable()) {
            graphics.method_27534(field_22793,
                    class_2561.method_43470("Developer Environment ON"),
                    field_22789 / 2, 32, theme.mutedTextColor());
        } else {
            graphics.method_27534(field_22793,
                    class_2561.method_43470("Developer tools are disabled. Re-enable devEnvironment in flintquests.json."),
                    field_22789 / 2, 32, theme.mutedTextColor());
        }

        if (!exportStatus.isBlank()) {
            int color = exportFailed ? theme.errorTextColor() : theme.completedColor();
            graphics.method_27534(field_22793, class_2561.method_43470(exportStatus), field_22789 / 2, field_22790 - 10, color);
        }
        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (FlintQuestsClient.handleEditingToggleKey(event)) return true;
        return super.method_25404(event);
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }
}
