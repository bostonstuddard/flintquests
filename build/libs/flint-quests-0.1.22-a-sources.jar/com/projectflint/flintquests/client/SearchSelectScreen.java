package com.projectflint.flintquests.client;

import com.projectflint.flintquests.data.CategoryRepository;
import com.projectflint.flintquests.data.QuestCategoryDefinition;
import com.projectflint.flintquests.data.QuestDefinition;
import com.projectflint.flintquests.data.QuestRepository;
import com.projectflint.flintquests.theme.QuestThemeManager;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import net.minecraft.class_11908;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7923;

public final class SearchSelectScreen extends class_437 {
    public enum Kind {
        ITEM,
        BLOCK,
        CATEGORY_PAGE,
        CATEGORY_ANY,
        QUEST
    }

    private static final int VISIBLE_ROWS = 10;

    private final class_437 parent;
    private final Kind kind;
    private final Consumer<String> onSelect;
    private final List<Entry> allEntries = new ArrayList<>();
    private final List<Entry> filtered = new ArrayList<>();
    private final List<class_4185> resultButtons = new ArrayList<>();

    private class_342 searchBox;
    private int scrollOffset;

    public SearchSelectScreen(class_437 parent, class_2561 title, Kind kind, Consumer<String> onSelect) {
        super(title);
        this.parent = parent;
        this.kind = kind;
        this.onSelect = onSelect;
        loadEntries();
    }

    private void loadEntries() {
        allEntries.clear();
        switch (kind) {
            case ITEM -> class_7923.field_41178.method_10220().forEach(item -> {
                String id = class_7923.field_41178.method_10221(item).toString();
                String name = new class_1799(item).method_7964().getString();
                allEntries.add(new Entry(id, name + "  (" + id + ")"));
            });
            case BLOCK -> class_7923.field_41175.method_10220().forEach(block -> {
                String id = class_7923.field_41175.method_10221(block).toString();
                String name = block.method_9518().getString();
                allEntries.add(new Entry(id, name + "  (" + id + ")"));
            });
            case CATEGORY_PAGE -> CategoryRepository.all().stream()
                    .filter(category -> category.selectable)
                    .forEach(category -> allEntries.add(new Entry(category.id, category.title + "  (" + category.id + ")")));
            case CATEGORY_ANY -> CategoryRepository.all().forEach(category ->
                    allEntries.add(new Entry(category.id, category.title + "  (" + category.id + ")")));
            case QUEST -> QuestRepository.all().forEach(quest ->
                    allEntries.add(new Entry(quest.id, quest.title + "  (" + quest.id + ")")));
        }
        allEntries.sort(Comparator.comparing(Entry::display, String.CASE_INSENSITIVE_ORDER));
        filtered.addAll(allEntries);
    }

    @Override
    protected void method_25426() {
        int panelWidth = Math.min(440, field_22789 - 48);
        int left = field_22789 / 2 - panelWidth / 2;
        searchBox = new class_342(field_22793, left + 12, 40, panelWidth - 24, 20, class_2561.method_43470("Search"));
        searchBox.method_1880(128);
        searchBox.method_1863(value -> applyFilter());
        method_37063(searchBox);

        resultButtons.clear();
        for (int i = 0; i < VISIBLE_ROWS; i++) {
            final int row = i;
            class_4185 button = class_4185.method_46430(class_2561.method_43473(), ignored -> selectRow(row))
                    .method_46434(left + 12, 68 + i * 22, panelWidth - 24, 20)
                    .method_46431();
            resultButtons.add(button);
            method_37063(button);
        }

        method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), button -> method_25419())
                .method_46434(field_22789 / 2 - 40, field_22790 - 30, 80, 20).method_46431());
        refreshRows();
    }

    private void applyFilter() {
        String query = searchBox == null ? "" : searchBox.method_1882().trim().toLowerCase(Locale.ROOT);
        filtered.clear();
        if (query.isBlank()) {
            filtered.addAll(allEntries);
        } else {
            for (Entry entry : allEntries) {
                if (entry.id().toLowerCase(Locale.ROOT).contains(query)
                        || entry.display().toLowerCase(Locale.ROOT).contains(query)) {
                    filtered.add(entry);
                }
            }
        }
        scrollOffset = 0;
        refreshRows();
    }

    private void refreshRows() {
        int maxOffset = Math.max(0, filtered.size() - VISIBLE_ROWS);
        scrollOffset = Math.max(0, Math.min(maxOffset, scrollOffset));
        for (int i = 0; i < resultButtons.size(); i++) {
            int index = scrollOffset + i;
            class_4185 button = resultButtons.get(i);
            if (index < filtered.size()) {
                button.field_22763 = true;
                button.method_25355(class_2561.method_43470(filtered.get(index).display()));
            } else {
                button.field_22763 = false;
                button.method_25355(class_2561.method_43473());
            }
        }
    }

    private void selectRow(int row) {
        int index = scrollOffset + row;
        if (index < 0 || index >= filtered.size()) return;
        onSelect.accept(filtered.get(index).id());
        field_22787.method_1507(parent);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontal, double vertical) {
        if (vertical != 0.0D) {
            scrollOffset -= (int) Math.signum(vertical);
            refreshRows();
            return true;
        }
        return super.method_25401(mouseX, mouseY, horizontal, vertical);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        int panelWidth = Math.min(440, field_22789 - 48);
        int left = field_22789 / 2 - panelWidth / 2;
        int panelTop = 18;
        int panelBottom = Math.min(field_22790 - 38, 68 + VISIBLE_ROWS * 22 + 10);
                graphics.method_25294(0, 0, field_22789, field_22790, QuestThemeManager.current().backgroundColor());
        graphics.method_25294(left, panelTop, left + panelWidth, panelBottom, QuestThemeManager.current().panelColor());
        graphics.method_27534(field_22793, field_22785, field_22789 / 2, 25, QuestThemeManager.current().titleTextColor());
        graphics.method_51439(field_22793, class_2561.method_43470(filtered.size() + " result(s)"), left + 12, panelBottom - 13, QuestThemeManager.current().mutedTextColor(), false);

        super.method_25394(graphics, mouseX, mouseY, partialTick);

        if (kind == Kind.ITEM || kind == Kind.BLOCK) {
            for (int i = 0; i < VISIBLE_ROWS; i++) {
                int index = scrollOffset + i;
                if (index >= filtered.size()) break;
                graphics.method_51427(QuestIconHelper.stackFor(filtered.get(index).id()), left + 16, 70 + i * 22);
            }
        } else if (kind == Kind.CATEGORY_PAGE || kind == Kind.CATEGORY_ANY) {
            for (int i = 0; i < VISIBLE_ROWS; i++) {
                int index = scrollOffset + i;
                if (index >= filtered.size()) break;
                QuestCategoryDefinition category = CategoryRepository.get(filtered.get(index).id());
                if (category != null) graphics.method_51427(QuestIconHelper.stackFor(category.icon), left + 16, 70 + i * 22);
            }
        } else if (kind == Kind.QUEST) {
            for (int i = 0; i < VISIBLE_ROWS; i++) {
                int index = scrollOffset + i;
                if (index >= filtered.size()) break;
                QuestDefinition quest = QuestRepository.get(filtered.get(index).id());
                if (quest != null) graphics.method_51427(QuestIconHelper.stackFor(quest), left + 16, 70 + i * 22);
            }
        }
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (FlintQuestsClient.handleEditingToggleKey(event)) return true;
        return super.method_25404(event);
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }

    private record Entry(String id, String display) {
    }
}
