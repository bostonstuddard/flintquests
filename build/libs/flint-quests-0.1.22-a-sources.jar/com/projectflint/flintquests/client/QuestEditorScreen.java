package com.projectflint.flintquests.client;

import com.projectflint.flintquests.config.ConfigManager;
import com.projectflint.flintquests.data.CompletionMode;
import com.projectflint.flintquests.data.QuestDefinition;
import com.projectflint.flintquests.data.QuestNodeShape;
import com.projectflint.flintquests.data.QuestRepository;
import com.projectflint.flintquests.data.QuestTask;
import com.projectflint.flintquests.data.TaskType;
import com.projectflint.flintquests.network.QuestProgressRequestC2SPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7529;
import com.projectflint.flintquests.theme.QuestThemeManager;
import java.util.ArrayList;
import java.util.Arrays;

public final class QuestEditorScreen extends class_437 {
	private static final String QUEST_NAMESPACE = "flintquests:";

	private enum EditorPage {
		QUEST("Quest"),
		LOOK("Look"),
		FLOW("Flow"),
		RULES("Rules"),
		TASK("Task");

		private final String title;

		EditorPage(String title) {
			this.title = title;
		}
	}

	private final class_437 parent;
	private final QuestDefinition original;
	private final QuestDefinition draft;
	private EditorPage page = EditorPage.QUEST;

	private class_342 idPathBox;
	private class_342 titleBox;
	private class_7529 descriptionBox;
	private class_342 chapterBox;
	private class_342 iconBox;
	private class_342 dependenciesBox;
	private class_342 xBox;
	private class_342 yBox;

	private class_342 taskIdBox;
	private class_342 taskLabelBox;
	private class_342 taskTargetBox;
	private class_342 taskCountBox;
	private int taskIndex;
	private TaskType currentTaskType = TaskType.OBTAIN_ITEM;
	private boolean currentTaskOptional;
	private class_4185 taskTypeButton;
	private class_4185 taskOptionalButton;
	private class_4185 targetSearchButton;
	private String saveError = "";

	private int row0;
	private int row1;
	private int row2;
	private int row3;
	private int row4;

	public QuestEditorScreen(class_437 parent, QuestDefinition definition) {
		this(parent, definition, null);
	}

	public QuestEditorScreen(class_437 parent, QuestDefinition definition, String defaultCategory) {
		super(class_2561.method_43470(definition == null ? "Create Quest" : "Edit Quest"));
		this.parent = parent;
		this.original = definition;
		this.draft = definition == null ? new QuestDefinition() : copy(definition);
		if (definition == null && defaultCategory != null && !defaultCategory.isBlank()) {
			this.draft.chapter = defaultCategory.trim();
		}
		if (this.draft.tasks.isEmpty()) {
			this.draft.tasks.add(new QuestTask("task_0", TaskType.OBTAIN_ITEM, "Obtain a stick", "minecraft:stick", 1, false));
		}
	}

	@Override
	protected void method_25426() {
		if (!ConfigManager.devToolsEnabled()) {
			field_22787.method_1507(parent);
			return;
		}
		EditorLayout layout = layout();
		buildTabs(layout);
		switch (page) {
			case QUEST -> buildQuestPage(layout);
			case LOOK -> buildLookPage(layout);
			case FLOW -> buildFlowPage(layout);
			case RULES -> buildRulesPage(layout);
			case TASK -> buildTaskPage(layout);
		}
		buildFooter(layout);
	}

	private void buildTabs(EditorLayout layout) {
		int gap = 2;
		int tabWidth = Math.max(38, (layout.panelWidth() - gap * 4) / 5);
		EditorPage[] pages = EditorPage.values();
		for (int i = 0; i < pages.length; i++) {
			EditorPage target = pages[i];
			String label = target == page ? "[" + target.title + "]" : target.title;
			method_37063(class_4185.method_46430(class_2561.method_43470(label), button -> switchPage(target))
					.method_46434(layout.left() + i * (tabWidth + gap), 5, tabWidth, 18).method_46431());
		}
	}

	private void buildQuestPage(EditorLayout layout) {
		int x = layout.contentLeft();
		int width = layout.contentWidth();
		int y = layout.contentTop();
		int namespaceWidth = Math.min(width - 70, Math.max(76, field_22793.method_1727(QUEST_NAMESPACE) + 8));
		row0 = y;
		idPathBox = field(x + namespaceWidth, y + 11, width - namespaceWidth, 18, idPath(draft.id));
		y += 34;
		row1 = y;
		titleBox = field(x, y + 11, width, 18, draft.title);
		y += 34;
		row2 = y;
		int descriptionHeight = Math.max(28, layout.panelBottom() - (y + 12) - 8);
		descriptionBox = class_7529.method_71507()
				.method_71508(x)
				.method_71512(y + 12)
				.method_71510(class_2561.method_43470("One instruction per line..."))
				.method_71509(field_22793, width, descriptionHeight, class_2561.method_43470("Quest description / lore"));
		descriptionBox.method_44402(4096);
		descriptionBox.method_72234(normalizeLegacyNewlines(draft.description), true);
		method_37063(descriptionBox);
	}

	private void buildLookPage(EditorLayout layout) {
		int x = layout.contentLeft();
		int width = layout.contentWidth();
		int y = layout.contentTop();
		row0 = y;
		chapterBox = field(x, y + 11, width - 62, 18, draft.chapter);
		method_37063(class_4185.method_46430(class_2561.method_43470("Choose"), button -> chooseCategory())
				.method_46434(x + width - 56, y + 11, 56, 18).method_46431());
		y += 38;
		row1 = y;
		iconBox = field(x, y + 11, width - 62, 18, draft.icon);
		method_37063(class_4185.method_46430(class_2561.method_43470("Search"), button -> searchIcon())
				.method_46434(x + width - 56, y + 11, 56, 18).method_46431());
		y += 38;
		row2 = y;
		method_37063(class_4185.method_46430(shapeLabel(), button -> {
			draft.nodeShape = effectiveShape().next();
			button.method_25355(shapeLabel());
		}).method_46434(x, y + 11, width, 20).method_46431());
	}

	private void buildFlowPage(EditorLayout layout) {
		int x = layout.contentLeft();
		int width = layout.contentWidth();
		int y = layout.contentTop();
		row0 = y;
		int half = Math.max(40, (width - 8) / 2);
		int otherHalf = Math.max(40, width - half - 8);
		xBox = field(x, y + 18, half, 18, Integer.toString(draft.x));
		yBox = field(x + half + 8, y + 18, otherHalf, 18, Integer.toString(draft.y));
	}

	private void buildRulesPage(EditorLayout layout) {
		int x = layout.contentLeft();
		int width = layout.contentWidth();
		int y = layout.contentTop();
		int rowStep = Math.max(31, Math.min(39, (layout.panelBottom() - y - 4) / 4));

		row0 = y;
		dependenciesBox = field(x, y + 11, width - 62, 18, String.join(",", draft.dependencies));
		method_37063(class_4185.method_46430(class_2561.method_43470("Add"), button -> addDependency())
				.method_46434(x + width - 56, y + 11, 56, 18).method_46431());
		y += rowStep;

		row1 = y;
		method_37063(class_4185.method_46430(class_2561.method_43470("Required quests: " + draft.dependencyMode), button -> {
			draft.dependencyMode = draft.dependencyMode == CompletionMode.ALL ? CompletionMode.ANY : CompletionMode.ALL;
			button.method_25355(class_2561.method_43470("Required quests: " + draft.dependencyMode));
		}).method_46434(x, y + 11, width, 20).method_46431());
		y += rowStep;

		row2 = y;
		method_37063(class_4185.method_46430(class_2561.method_43470("Tasks: " + draft.taskMode), button -> {
			draft.taskMode = draft.taskMode == CompletionMode.ALL ? CompletionMode.ANY : CompletionMode.ALL;
			button.method_25355(class_2561.method_43470("Tasks: " + draft.taskMode));
		}).method_46434(x, y + 11, width, 20).method_46431());
		y += rowStep;

		row3 = y;
		method_37063(class_4185.method_46430(hiddenLabel(), button -> {
			draft.hiddenUntilDependencies = !draft.hiddenUntilDependencies;
			button.method_25355(hiddenLabel());
		}).method_46434(x, y + 11, width, 20).method_46431());
	}

	private void buildTaskPage(EditorLayout layout) {
		int x = layout.contentLeft();
		int width = layout.contentWidth();
		int y = layout.contentTop();
		int rowStep = compactRowStep(layout);

		int navWidth = Math.min(54, Math.max(34, width / 6));
		method_37063(class_4185.method_46430(class_2561.method_43470("<"), button -> previousTask())
				.method_46434(x, layout.panelTop() + 5, navWidth, 18).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470(">"), button -> nextTask())
				.method_46434(x + navWidth + 3, layout.panelTop() + 5, navWidth, 18).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("+"), button -> addTask())
				.method_46434(x + width - navWidth * 2 - 3, layout.panelTop() + 5, navWidth, 18).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("-"), button -> removeTask())
				.method_46434(x + width - navWidth, layout.panelTop() + 5, navWidth, 18).method_46431());

		row0 = y;
		taskIdBox = field(x, y + 11, width, 18, "");
		y += rowStep;
		row1 = y;
		taskLabelBox = field(x, y + 11, width, 18, "");
		y += rowStep;
		row2 = y;
		taskTypeButton = method_37063(class_4185.method_46430(class_2561.method_43473(), button -> cycleTaskType())
				.method_46434(x, y + 11, width, 20).method_46431());
		y += rowStep;
		row3 = y;
		taskTargetBox = field(x, y + 11, width - 62, 18, "");
		targetSearchButton = method_37063(class_4185.method_46430(class_2561.method_43470("Search"), button -> searchTaskTarget())
				.method_46434(x + width - 56, y + 11, 56, 18).method_46431());
		y += rowStep;
		row4 = y;
		int countWidth = Math.max(46, Math.min(100, width / 3));
		taskCountBox = field(x, y + 11, countWidth, 18, "1");
		int optionalWidth = Math.max(40, width - countWidth - 8);
		taskOptionalButton = method_37063(class_4185.method_46430(class_2561.method_43473(), button -> {
			currentTaskOptional = !currentTaskOptional;
			updateTaskButtonLabels();
		}).method_46434(x + countWidth + 8, y + 11, optionalWidth, 18).method_46431());
		loadTaskFields();
	}

	private int compactRowStep(EditorLayout layout) {
		int available = Math.max(100, layout.panelBottom() - layout.contentTop() - 2);
		return Math.max(22, Math.min(34, available / 5));
	}

	private void buildFooter(EditorLayout layout) {
		int gap = 3;
		int available = Math.max(160, Math.min(430, field_22789 - 8));
		int left = field_22789 / 2 - available / 2;
		int count = original == null ? 2 : 3;
		int buttonWidth = Math.max(48, (available - gap * (count - 1)) / count);
		int x = left;
		method_37063(class_4185.method_46430(class_2561.method_43470("Save Quest"), button -> saveAndClose())
				.method_46434(x, layout.footerY(), buttonWidth, 20).method_46431());
		x += buttonWidth + gap;
		method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), button -> method_25419())
				.method_46434(x, layout.footerY(), buttonWidth, 20).method_46431());
		if (original != null) {
			x += buttonWidth + gap;
			method_37063(class_4185.method_46430(class_2561.method_43470("Delete Quest"), button -> deleteAndClose())
					.method_46434(x, layout.footerY(), buttonWidth, 20).method_46431());
		}
	}

	private void switchPage(EditorPage target) {
		if (target == page) return;
		saveVisiblePage();
		page = target;
		method_37067();
		method_25426();
	}

	private void saveVisiblePage() {
		switch (page) {
			case QUEST -> saveQuestPage();
			case LOOK -> saveLookPage();
			case FLOW -> saveFlowPage();
			case RULES -> saveRulesPage();
			case TASK -> saveTaskFields();
		}
	}

	private QuestNodeShape effectiveShape() {
		return draft.nodeShape == null ? QuestNodeShape.SQUARE : draft.nodeShape;
	}

	private class_2561 shapeLabel() {
		return class_2561.method_43470("Node shape: " + effectiveShape().displayName());
	}

	private class_2561 hiddenLabel() {
		return class_2561.method_43470("Hide until ready: " + (draft.hiddenUntilDependencies ? "Yes" : "No"));
	}

	private class_342 field(int x, int y, int width, int height, String value) {
		class_342 box = new class_342(field_22793, x, y, Math.max(36, width), height, class_2561.method_43473());
		box.method_1880(512);
		box.method_1852(value == null ? "" : value);
		method_37063(box);
		return box;
	}

	private void chooseCategory() {
		saveLookPage();
		field_22787.method_1507(new SearchSelectScreen(this, class_2561.method_43470("Choose Quest Category"), SearchSelectScreen.Kind.CATEGORY_PAGE,
				id -> draft.chapter = id));
	}

	private void searchIcon() {
		saveLookPage();
		field_22787.method_1507(new SearchSelectScreen(this, class_2561.method_43470("Choose Quest Icon"), SearchSelectScreen.Kind.ITEM,
				id -> draft.icon = id));
	}

	private void addDependency() {
		saveRulesPage();
		field_22787.method_1507(new SearchSelectScreen(this, class_2561.method_43470("Add Required Quest — any category"), SearchSelectScreen.Kind.QUEST,
				id -> {
					if (!id.equals(draft.id) && !draft.dependencies.contains(id)) draft.dependencies.add(id);
				}));
	}

	private void searchTaskTarget() {
		SearchSelectScreen.Kind kind = switch (currentTaskType) {
			case OBTAIN_ITEM, USE_ITEM -> SearchSelectScreen.Kind.ITEM;
			case BREAK_BLOCK, INTERACT_BLOCK -> SearchSelectScreen.Kind.BLOCK;
			default -> null;
		};
		if (kind == null) return;
		saveTaskFields();
		int selectedTask = taskIndex;
		field_22787.method_1507(new SearchSelectScreen(this, class_2561.method_43470("Choose Task Target"), kind,
				id -> draft.tasks.get(selectedTask).target = id));
	}

	private void cycleTaskType() {
		saveTaskFields();
		TaskType[] values = TaskType.values();
		currentTaskType = values[(currentTaskType.ordinal() + 1) % values.length];
		draft.tasks.get(taskIndex).type = currentTaskType;
		if (currentTaskType == TaskType.CHECKMARK) {
			taskTargetBox.method_1852("");
			taskCountBox.method_1852("1");
		}
		updateTaskButtonLabels();
	}

	private void previousTask() {
		saveTaskFields();
		if (taskIndex > 0) taskIndex--;
		loadTaskFields();
	}

	private void nextTask() {
		saveTaskFields();
		if (taskIndex < draft.tasks.size() - 1) taskIndex++;
		loadTaskFields();
	}

	private void addTask() {
		saveTaskFields();
		draft.tasks.add(new QuestTask("task_" + draft.tasks.size(), TaskType.OBTAIN_ITEM, "", "minecraft:stick", 1, false));
		taskIndex = draft.tasks.size() - 1;
		loadTaskFields();
	}

	private void removeTask() {
		if (draft.tasks.size() <= 1) return;
		draft.tasks.remove(taskIndex);
		taskIndex = Math.max(0, Math.min(taskIndex, draft.tasks.size() - 1));
		loadTaskFields();
	}

	private void loadTaskFields() {
		if (taskIdBox == null || draft.tasks.isEmpty()) return;
		QuestTask task = draft.tasks.get(taskIndex);
		currentTaskType = task.type;
		currentTaskOptional = task.optional;
		taskIdBox.method_1852(task.id);
		taskLabelBox.method_1852(task.label == null ? "" : task.label);
		taskTargetBox.method_1852(task.target);
		taskCountBox.method_1852(Integer.toString(task.count));
		updateTaskButtonLabels();
	}

	private void updateTaskButtonLabels() {
		if (taskTypeButton != null) taskTypeButton.method_25355(class_2561.method_43470("Completion: " + friendlyTaskType(currentTaskType)));
		if (taskOptionalButton != null) taskOptionalButton.method_25355(class_2561.method_43470(currentTaskOptional ? "Optional" : "Required"));
		boolean searchableTarget = currentTaskType == TaskType.OBTAIN_ITEM || currentTaskType == TaskType.USE_ITEM
				|| currentTaskType == TaskType.BREAK_BLOCK || currentTaskType == TaskType.INTERACT_BLOCK;
		boolean hasTarget = currentTaskType != TaskType.CHECKMARK;
		if (targetSearchButton != null) targetSearchButton.field_22763 = searchableTarget;
		if (taskTargetBox != null) taskTargetBox.field_22763 = hasTarget;
		if (taskCountBox != null) taskCountBox.field_22763 = hasTarget;
	}

	private String friendlyTaskType(TaskType type) {
		return switch (type) {
			case OBTAIN_ITEM -> "Obtain Item";
			case BREAK_BLOCK -> "Break Block";
			case USE_ITEM -> "Use Item";
			case INTERACT_BLOCK -> "Interact With Block";
			case CUSTOM_EVENT -> "Flint/Custom Event";
			case CHECKMARK -> "Manual Checkmark";
		};
	}

	private void saveTaskFields() {
		if (draft.tasks.isEmpty() || taskIdBox == null) return;
		QuestTask task = draft.tasks.get(taskIndex);
		task.id = taskIdBox.method_1882().trim();
		task.type = currentTaskType;
		task.label = taskLabelBox.method_1882().trim();
		task.target = taskTargetBox.method_1882().trim();
		task.count = parseInt(taskCountBox.method_1882(), 1);
		task.optional = currentTaskOptional;
		task.normalize(taskIndex);
	}

	private void saveQuestPage() {
		if (idPathBox == null) return;
		String path = QuestDefinition.normalizeIdPath(idPathBox.method_1882());
		draft.id = QUEST_NAMESPACE + (path.isBlank() ? "new_quest" : path);
		draft.title = titleBox.method_1882().trim();
		draft.description = descriptionBox.method_44405();
	}

	private void saveLookPage() {
		if (chapterBox == null) return;
		draft.chapter = chapterBox.method_1882().trim();
		draft.icon = iconBox.method_1882().trim();
	}

	private void saveFlowPage() {
		if (xBox == null || yBox == null) return;
		draft.x = parseInt(xBox.method_1882(), 0);
		draft.y = parseInt(yBox.method_1882(), 0);
	}

	private void saveRulesPage() {
		if (dependenciesBox == null) return;
		draft.dependencies = new ArrayList<>();
		Arrays.stream(dependenciesBox.method_1882().split(","))
				.map(String::trim)
				.filter(value -> !value.isBlank())
				.filter(value -> !value.equals(draft.id))
				.forEach(draft.dependencies::add);
	}

	private void saveAndClose() {
		saveError = "";
		saveVisiblePage();
		draft.normalize();
		String previousId = original == null ? "" : original.id;
		QuestDefinition collision = QuestRepository.get(draft.id);
		if (collision != null && !collision.id.equals(previousId)) {
			saveError = "That quest ID is already in use.";
			return;
		}
		try {
			if (original == null) QuestRepository.save(draft);
			else QuestRepository.saveRenamed(previousId, draft);
			QuestRepository.load();
			field_22787.method_1507(parent);
		} catch (IllegalArgumentException exception) {
			saveError = exception.getMessage();
		}
	}

	private void deleteAndClose() {
		if (original != null) {
			String deletedId = original.id;
			QuestRepository.delete(deletedId);
			QuestRepository.load();
			ClientQuestProgress.removeQuest(deletedId);
			if (field_22787 != null && field_22787.field_1724 != null) {
				ClientPlayNetworking.send(new QuestProgressRequestC2SPayload("quest_deleted"));
			}
		} else {
			QuestRepository.load();
		}
		field_22787.method_1507(parent);
	}

	private int parseInt(String text, int fallback) {
		try {
			return Integer.parseInt(text.trim());
		} catch (NumberFormatException ignored) {
			return fallback;
		}
	}

	private String idPath(String id) {
		if (id == null || id.isBlank()) return "new_quest";
		int split = id.indexOf(':');
		return split >= 0 ? id.substring(split + 1) : id;
	}

	private String normalizeLegacyNewlines(String value) {
		return value == null ? "" : value.replace("\\n", "\n").replace("\r", "");
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
		EditorLayout layout = layout();
				graphics.method_25294(0, 0, field_22789, field_22790, QuestThemeManager.current().backgroundColor());
		graphics.method_25294(layout.left(), layout.panelTop(), layout.left() + layout.panelWidth(), layout.panelBottom(), QuestThemeManager.current().panelColor());
		switch (page) {
			case QUEST -> renderQuestLabels(graphics, layout);
			case LOOK -> renderLookLabels(graphics, layout);
			case FLOW -> renderFlowLabels(graphics, layout);
			case RULES -> renderRulesLabels(graphics, layout);
			case TASK -> renderTaskLabels(graphics, layout);
		}
		if (!saveError.isBlank()) {
			graphics.method_27534(field_22793, class_2561.method_43470(saveError), field_22789 / 2, Math.max(24, layout.footerY() - 10), QuestThemeManager.current().errorTextColor());
		}
		super.method_25394(graphics, mouseX, mouseY, partialTick);
	}

	private void renderQuestLabels(class_332 graphics, EditorLayout layout) {
		int x = layout.contentLeft();
		int namespaceWidth = Math.min(layout.contentWidth() - 70, Math.max(76, field_22793.method_1727(QUEST_NAMESPACE) + 8));
		label(graphics, "Quest ID", x, row0);
		graphics.method_25294(x, row0 + 11, x + namespaceWidth, row0 + 29, 0xFF10161D);
		graphics.method_51439(field_22793, class_2561.method_43470(QUEST_NAMESPACE), x + 4, row0 + 16, QuestThemeManager.current().mutedTextColor(), false);
		label(graphics, "Title shown to players", x, row1);
		label(graphics, "Description / instructions — Enter = new line", x, row2);
	}

	private void renderLookLabels(class_332 graphics, EditorLayout layout) {
		int x = layout.contentLeft();
		label(graphics, "Category", x, row0);
		label(graphics, "Quest icon", x, row1);
		label(graphics, "Node shape", x, row2);
	}

	private void renderFlowLabels(class_332 graphics, EditorLayout layout) {
		int x = layout.contentLeft();
		label(graphics, "Canvas node position", x, row0);
		graphics.method_51439(field_22793, class_2561.method_43470("X"), x, row0 + 10, QuestThemeManager.current().mutedTextColor(), false);
		int half = Math.max(40, (layout.contentWidth() - 8) / 2);
		graphics.method_51439(field_22793, class_2561.method_43470("Y"), x + half + 8, row0 + 10, QuestThemeManager.current().mutedTextColor(), false);
	}

	private void renderRulesLabels(class_332 graphics, EditorLayout layout) {
		int x = layout.contentLeft();
		label(graphics, "Required quests — may be from any category", x, row0);
		label(graphics, "Required-quest rule", x, row1);
		label(graphics, "Task rule", x, row2);
		label(graphics, "Visibility", x, row3);
	}

	private void renderTaskLabels(class_332 graphics, EditorLayout layout) {
		int x = layout.contentLeft();
		graphics.method_27534(field_22793, class_2561.method_43470("Task " + (taskIndex + 1) + " / " + draft.tasks.size()), field_22789 / 2, layout.panelTop() + 9, QuestThemeManager.current().accentTextColor());
		label(graphics, "Internal task ID", x, row0);
		label(graphics, "Task text shown to players", x, row1);
		label(graphics, "Completion condition", x, row2);
		String targetLabel = currentTaskType == TaskType.CHECKMARK
				? "Manual Checkmark: no target"
				: switch (currentTaskType) {
					case OBTAIN_ITEM, USE_ITEM -> "Target item";
					case BREAK_BLOCK, INTERACT_BLOCK -> "Target block";
					case CUSTOM_EVENT -> "Custom API event ID";
					case CHECKMARK -> "Manual Checkmark: no target";
				};
		label(graphics, targetLabel, x, row3);
		label(graphics, currentTaskType == TaskType.CHECKMARK ? "Count fixed at 1" : "Required count", x, row4);
	}

	private EditorLayout layout() {
		int margin = Math.max(3, Math.min(14, field_22789 / 28));
		int panelWidth = Math.max(180, Math.min(560, field_22789 - margin * 2));
		if (panelWidth > field_22789 - 4) panelWidth = Math.max(150, field_22789 - 4);
		int left = Math.max(2, field_22789 / 2 - panelWidth / 2);
		int panelTop = 27;
		int footerY = Math.max(0, field_22790 - 22);
		int panelBottom = Math.max(panelTop + 50, footerY - 4);
		int contentLeft = left + Math.max(7, Math.min(14, panelWidth / 24));
		int contentWidth = Math.max(100, panelWidth - (contentLeft - left) * 2);
		int contentTop = panelTop + 26;
		return new EditorLayout(left, panelWidth, panelTop, panelBottom, contentLeft, contentWidth, contentTop, footerY);
	}

	private void label(class_332 graphics, String text, int x, int y) {
		graphics.method_51439(field_22793, class_2561.method_43470(text), x, y, QuestThemeManager.current().labelTextColor(), false);
	}

	@Override
	public boolean method_25404(class_11908 event) {
		if (FlintQuestsClient.handleEditingToggleKey(event)) return true;
		return super.method_25404(event);
	}

	@Override
	public void method_25419() {
		field_22787.method_1507(parent);
	}

	private record EditorLayout(int left, int panelWidth, int panelTop, int panelBottom, int contentLeft,
			int contentWidth, int contentTop, int footerY) {
	}

	private static QuestDefinition copy(QuestDefinition source) {
		QuestDefinition copy = new QuestDefinition();
		copy.id = source.id;
		copy.chapter = source.chapter;
		copy.title = source.title;
		copy.description = source.description;
		copy.icon = source.icon;
		copy.nodeShape = source.nodeShape == null ? QuestNodeShape.SQUARE : source.nodeShape;
		copy.x = source.x;
		copy.y = source.y;
		copy.hiddenUntilDependencies = source.hiddenUntilDependencies;
		copy.dependencyMode = source.dependencyMode;
		copy.taskMode = source.taskMode;
		copy.dependencies = new ArrayList<>(source.dependencies);
		copy.tasks = new ArrayList<>();
		for (QuestTask task : source.tasks) {
			copy.tasks.add(new QuestTask(task.id, task.type, task.label, task.target, task.count, task.optional));
		}
		return copy;
	}
}
