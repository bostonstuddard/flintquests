package com.projectflint.flintquests.client;

import com.projectflint.flintquests.config.ConfigManager;
import com.projectflint.flintquests.data.CategoryRepository;
import com.projectflint.flintquests.data.QuestCategoryDefinition;
import com.projectflint.flintquests.data.QuestDefinition;
import com.projectflint.flintquests.data.QuestRepository;
import com.projectflint.flintquests.theme.QuestThemeManager;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class CategoryEditorScreen extends class_437 {
    private final class_437 parent;
    private final QuestCategoryDefinition original;
    private final QuestCategoryDefinition draft;

    private class_342 idBox;
    private class_342 titleBox;
    private class_342 iconBox;
    private class_342 parentBox;
    private class_342 orderBox;
    private class_4185 typeButton;

    public CategoryEditorScreen(class_437 parent, QuestCategoryDefinition category) {
        super(class_2561.method_43470(category == null ? "Create Quest Category" : "Edit Quest Category"));
        this.parent = parent;
        this.original = category == null ? null : category.copy();
        this.draft = category == null ? new QuestCategoryDefinition() : category.copy();
        if (category == null) {
            draft.id = "new_category";
            draft.title = "New Category";
            draft.icon = "minecraft:book";
            draft.parent = "";
            draft.selectable = true;
        }
    }

    @Override
    protected void method_25426() {
        if (!ConfigManager.devToolsEnabled()) {
            field_22787.method_1507(parent);
            return;
        }
        Layout layout = layout();
        int fieldWidth = layout.panelWidth() - 24;
        int fieldHeight = 18;

        if (original == null) {
            idBox = field(layout.left() + 12, layout.row(0) + 11, fieldWidth, fieldHeight, draft.id);
        }
        titleBox = field(layout.left() + 12, layout.row(1) + 11, fieldWidth, fieldHeight, draft.title);

        typeButton = method_37063(class_4185.method_46430(typeLabel(), button -> {
                    draft.selectable = !draft.selectable;
                    button.method_25355(typeLabel());
                })
                .method_46434(layout.left() + 12, layout.row(2) + 11, fieldWidth, fieldHeight).method_46431());

        iconBox = field(layout.left() + 12, layout.row(3) + 11, fieldWidth - 66, fieldHeight, draft.icon);
        parentBox = field(layout.left() + 12, layout.row(4) + 11, fieldWidth - 66, fieldHeight, draft.parent);
        orderBox = field(layout.left() + 12, layout.row(5) + 11, 72, fieldHeight, Integer.toString(draft.order));

        method_37063(class_4185.method_46430(class_2561.method_43470("Search"), button -> {
                    saveFieldsToDraft();
                    field_22787.method_1507(new SearchSelectScreen(this, class_2561.method_43470("Choose Category Icon"), SearchSelectScreen.Kind.ITEM,
                            id -> draft.icon = id));
                })
                .method_46434(layout.left() + layout.panelWidth() - 66, layout.row(3) + 11, 54, fieldHeight).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Choose"), button -> {
                    saveFieldsToDraft();
                    field_22787.method_1507(new SearchSelectScreen(this, class_2561.method_43470("Choose Parent Category"), SearchSelectScreen.Kind.CATEGORY_ANY,
                            id -> draft.parent = id));
                })
                .method_46434(layout.left() + layout.panelWidth() - 66, layout.row(4) + 11, 54, fieldHeight).method_46431());

        int bottom = layout.bottomButtonY();
        method_37063(class_4185.method_46430(class_2561.method_43470("Save Category"), button -> saveAndClose())
                .method_46434(field_22789 / 2 - 130, bottom, 96, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), button -> method_25419())
                .method_46434(field_22789 / 2 - 28, bottom, 72, 20).method_46431());
        if (original != null) {
            method_37063(class_4185.method_46430(class_2561.method_43470("Delete Category"), button -> deleteAndClose())
                    .method_46434(field_22789 / 2 + 50, bottom, 104, 20).method_46431());
        }
    }

    private class_2561 typeLabel() {
        return class_2561.method_43470(draft.selectable
                ? "Type: Quest Page (opens a quest canvas)"
                : "Type: Group Header (dropdown only)");
    }

    private class_342 field(int x, int y, int width, int height, String value) {
        class_342 box = new class_342(field_22793, x, y, width, height, class_2561.method_43473());
        box.method_1880(256);
        box.method_1852(value == null ? "" : value);
        method_37063(box);
        return box;
    }

    private void saveFieldsToDraft() {
        if (original == null && idBox != null) draft.id = idBox.method_1882().trim();
        else if (original != null) draft.id = original.id;
        draft.title = titleBox.method_1882().trim();
        draft.icon = iconBox.method_1882().trim();
        draft.parent = parentBox.method_1882().trim();
        draft.order = parseInt(orderBox.method_1882(), 0);
    }

    private void saveAndClose() {
        saveFieldsToDraft();
        String previousId = original == null ? "" : original.id;
        if (draft.parent.equals(draft.id)) draft.parent = "";
        draft.normalize();

        if (original != null && !previousId.equals(draft.id)) {
            for (QuestCategoryDefinition category : CategoryRepository.all()) {
                if (!previousId.equals(category.parent)) continue;
                QuestCategoryDefinition updatedChild = category.copy();
                updatedChild.parent = draft.id;
                CategoryRepository.save(updatedChild);
            }
            for (QuestDefinition quest : QuestRepository.all()) {
                if (!previousId.equals(quest.chapter)) continue;
                quest.chapter = draft.id;
                QuestRepository.save(quest);
            }
            if (CategoryRepository.isExplicit(previousId)) CategoryRepository.delete(previousId);
        }

        CategoryRepository.save(draft);
        CategoryRepository.load();
        field_22787.method_1507(parent);
    }

    private void deleteAndClose() {
        if (original == null) {
            method_25419();
            return;
        }

        String deletedId = original.id;
        String replacementParent = original.parent == null ? "" : original.parent.trim();

        for (QuestCategoryDefinition category : CategoryRepository.all()) {
            if (!deletedId.equals(category.parent)) continue;
            QuestCategoryDefinition updated = category.copy();
            updated.parent = replacementParent;
            CategoryRepository.save(updated);
        }

        String fallbackPage = findFallbackQuestPage(deletedId, replacementParent);
        for (QuestDefinition quest : QuestRepository.all()) {
            if (!deletedId.equals(quest.chapter)) continue;
            quest.chapter = fallbackPage;
            QuestRepository.save(quest);
        }

        CategoryRepository.delete(deletedId);
        CategoryRepository.load();
        QuestRepository.load();
        field_22787.method_1507(parent);
    }

    private String findFallbackQuestPage(String deletedId, String preferredParent) {
        QuestCategoryDefinition preferred = CategoryRepository.get(preferredParent);
        if (preferred != null && preferred.selectable && !preferred.id.equals(deletedId)) return preferred.id;

        for (QuestCategoryDefinition category : CategoryRepository.all()) {
            if (category.selectable && !category.id.equals(deletedId)) return category.id;
        }

        QuestCategoryDefinition fallback = new QuestCategoryDefinition();
        fallback.id = deletedId.equals("introduction") ? "uncategorized" : "introduction";
        fallback.title = deletedId.equals("introduction") ? "Uncategorized" : "Introduction";
        fallback.icon = "minecraft:book";
        fallback.parent = "";
        fallback.selectable = true;
        fallback.order = 0;
        CategoryRepository.save(fallback);
        return fallback.id;
    }

    private int parseInt(String text, int fallback) {
        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        Layout layout = layout();
                graphics.method_25294(0, 0, field_22789, field_22790, QuestThemeManager.current().backgroundColor());
        graphics.method_25294(layout.left(), layout.panelTop(), layout.left() + layout.panelWidth(), layout.panelBottom(), QuestThemeManager.current().panelColor());
        graphics.method_27534(field_22793, field_22785, field_22789 / 2, layout.panelTop() + 7, QuestThemeManager.current().titleTextColor());

        if (original == null) label(graphics, "Category ID", layout.left() + 12, layout.row(0));
        else label(graphics, "Category ID: " + original.id, layout.left() + 12, layout.row(0));
        label(graphics, "Display name", layout.left() + 12, layout.row(1));
        label(graphics, "Category behavior", layout.left() + 12, layout.row(2));
        label(graphics, "Icon item", layout.left() + 12, layout.row(3));
        label(graphics, "Parent category (blank = top level)", layout.left() + 12, layout.row(4));
        label(graphics, "Sort order", layout.left() + 12, layout.row(5));

        int noteY = Math.min(layout.panelBottom() - 14, layout.row(6));
        String note = draft.selectable
                ? "Quest Page: players can select this row and see quests assigned to it."
                : "Group Header: this row only expands/collapses its child categories.";
        graphics.method_51439(field_22793, class_2561.method_43470(note), layout.left() + 12, noteY, QuestThemeManager.current().mutedTextColor(), false);
        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    private Layout layout() {
        int panelWidth = Math.min(430, Math.max(260, field_22789 - 60));
        int left = field_22789 / 2 - panelWidth / 2;
        int panelTop = 12;
        int bottomButtonY = Math.max(0, field_22790 - 26);
        int panelBottom = Math.max(panelTop + 220, bottomButtonY - 6);
        int contentTop = panelTop + 27;
        int available = Math.max(180, panelBottom - contentTop - 22);
        int rowStep = Math.min(36, Math.max(29, available / 7));
        return new Layout(panelWidth, left, panelTop, panelBottom, contentTop, rowStep, bottomButtonY);
    }

    private void label(class_332 graphics, String text, int x, int y) {
        graphics.method_51439(field_22793, class_2561.method_43470(text), x, y, QuestThemeManager.current().labelTextColor(), false);
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (FlintQuestsClient.handleEditingToggleKey(event)) return true;
        return super.method_25404(event);
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }

    private record Layout(int panelWidth, int left, int panelTop, int panelBottom, int contentTop,
                          int rowStep, int bottomButtonY) {
        int row(int index) {
            return contentTop + index * rowStep;
        }
    }
}
