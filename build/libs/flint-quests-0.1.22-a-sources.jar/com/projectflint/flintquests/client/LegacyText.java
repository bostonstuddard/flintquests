package com.projectflint.flintquests.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

/**
 * Converts author-friendly legacy Minecraft formatting codes into Components.
 * Both '&' and the vanilla section-sign prefix are accepted.
 */
public final class LegacyText {
    private LegacyText() {
    }

    public static class_2561 parse(String raw) {
        String input = raw == null ? "" : raw;
        class_5250 result = class_2561.method_43473();
        List<class_124> active = new ArrayList<>();
        StringBuilder plain = new StringBuilder();

        for (int i = 0; i < input.length(); i++) {
            char current = input.charAt(i);
            if ((current == '&' || current == '\u00A7') && i + 1 < input.length()) {
                char code = Character.toLowerCase(input.charAt(i + 1));
                class_124 formatting = formatting(code);
                if (formatting != null) {
                    flush(result, plain, active);
                    i++;
                    if (code == 'r') {
                        active.clear();
                    } else if (isColorCode(code)) {
                        // Vanilla legacy color codes also clear decoration state.
                        active.clear();
                        active.add(formatting);
                    } else if (!active.contains(formatting)) {
                        active.add(formatting);
                    }
                    continue;
                }
            }
            plain.append(current);
        }

        flush(result, plain, active);
        return result;
    }

    public static List<class_2561> lines(String raw) {
        String normalized = (raw == null ? "" : raw)
                .replace("\\n", "\n")
                .replace("\r", "");
        String[] split = normalized.split("\n", -1);
        List<class_2561> lines = new ArrayList<>(split.length);
        for (String line : split) lines.add(parse(line));
        return lines;
    }

    private static void flush(class_5250 result, StringBuilder plain, List<class_124> active) {
        if (plain.isEmpty()) return;
        class_5250 part = class_2561.method_43470(plain.toString());
        if (!active.isEmpty()) part.method_27695(active.toArray(new class_124[0]));
        result.method_10852(part);
        plain.setLength(0);
    }

    private static boolean isColorCode(char code) {
        return (code >= '0' && code <= '9') || (code >= 'a' && code <= 'f');
    }

    private static class_124 formatting(char code) {
        return switch (code) {
            case '0' -> class_124.field_1074;
            case '1' -> class_124.field_1058;
            case '2' -> class_124.field_1077;
            case '3' -> class_124.field_1062;
            case '4' -> class_124.field_1079;
            case '5' -> class_124.field_1064;
            case '6' -> class_124.field_1065;
            case '7' -> class_124.field_1080;
            case '8' -> class_124.field_1063;
            case '9' -> class_124.field_1078;
            case 'a' -> class_124.field_1060;
            case 'b' -> class_124.field_1075;
            case 'c' -> class_124.field_1061;
            case 'd' -> class_124.field_1076;
            case 'e' -> class_124.field_1054;
            case 'f' -> class_124.field_1068;
            case 'k' -> class_124.field_1051;
            case 'l' -> class_124.field_1067;
            case 'm' -> class_124.field_1055;
            case 'n' -> class_124.field_1073;
            case 'o' -> class_124.field_1056;
            case 'r' -> class_124.field_1070;
            default -> null;
        };
    }
}
