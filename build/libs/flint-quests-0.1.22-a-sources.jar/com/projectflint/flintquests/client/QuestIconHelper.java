package com.projectflint.flintquests.client;

import com.projectflint.flintquests.data.QuestDefinition;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

final class QuestIconHelper {
	private QuestIconHelper() {
	}

	static class_1799 stackFor(QuestDefinition quest) {
		return stackFor(quest == null ? null : quest.icon);
	}

	static class_1799 stackFor(String itemId) {
		class_2960 id = class_2960.method_12829(itemId == null ? "" : itemId.trim());
		class_1792 item = id == null ? class_1802.field_8529 : class_7923.field_41178.method_63535(id);
		if (item == null || item == class_1802.field_8162) item = class_1802.field_8529;
		return new class_1799(item);
	}
}
