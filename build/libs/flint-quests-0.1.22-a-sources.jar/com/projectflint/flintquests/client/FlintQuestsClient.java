package com.projectflint.flintquests.client;

import com.projectflint.flintquests.FlintQuests;
import com.projectflint.flintquests.config.ConfigManager;
import com.projectflint.flintquests.data.QuestDefinition;
import com.projectflint.flintquests.data.QuestRepository;
import com.projectflint.flintquests.network.QuestCompletedS2CPayload;
import com.projectflint.flintquests.network.QuestProgressS2CPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class FlintQuestsClient implements ClientModInitializer {
    private static final class_304.class_11900 KEY_CATEGORY = class_304.class_11900.method_74698(
            class_2960.method_60655(FlintQuests.MOD_ID, "controls")
    );

    private static class_304 openKey;
    private static class_304 toggleEditingKey;
    private static class_304 toggleEditingModifierKey;
    private static class_304 linkNodesKey;
    private static class_304 moveNodesKey;

    @Override
    public void onInitializeClient() {
        ConfigManager.load();

        openKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.flintquests.open",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_J,
                KEY_CATEGORY
        ));

        if (ConfigManager.devEnvironmentAvailable()) {
            toggleEditingKey = KeyBindingHelper.registerKeyBinding(new class_304(
                    "key.flintquests.toggle_editing",
                    class_3675.class_307.field_1668,
                    GLFW.GLFW_KEY_J,
                    KEY_CATEGORY
            ));

            toggleEditingModifierKey = KeyBindingHelper.registerKeyBinding(new class_304(
                    "key.flintquests.toggle_editing_modifier",
                    class_3675.class_307.field_1668,
                    GLFW.GLFW_KEY_LEFT_CONTROL,
                    KEY_CATEGORY
            ));

            linkNodesKey = KeyBindingHelper.registerKeyBinding(new class_304(
                    "key.flintquests.link_nodes",
                    class_3675.class_307.field_1668,
                    GLFW.GLFW_KEY_LEFT_SHIFT,
                    KEY_CATEGORY
            ));

            moveNodesKey = KeyBindingHelper.registerKeyBinding(new class_304(
                    "key.flintquests.move_nodes",
                    class_3675.class_307.field_1668,
                    GLFW.GLFW_KEY_LEFT_ALT,
                    KEY_CATEGORY
            ));
        }

        ClientPlayNetworking.registerGlobalReceiver(QuestProgressS2CPayload.ID, (payload, context) ->
                context.client().execute(() -> {
                    ClientQuestProgress.applyJson(payload.json());
                    if (context.client().field_1755 instanceof QuestBookScreen book) book.refreshFromProgress();
                    if (context.client().field_1755 instanceof QuestDetailScreen detail) detail.refreshFromProgress();
                }));

        ClientPlayNetworking.registerGlobalReceiver(QuestCompletedS2CPayload.ID, (payload, context) ->
                context.client().execute(() -> {
                    ClientQuestProgress.markQuestComplete(payload.questId());
                    QuestDefinition quest = QuestRepository.get(payload.questId());
                    if (quest != null) QuestCompletionNotifier.show(context.client(), quest);
                    if (context.client().field_1755 instanceof QuestBookScreen book) book.refreshFromProgress();
                    if (context.client().field_1755 instanceof QuestDetailScreen detail) detail.refreshFromProgress();
                }));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            boolean editingModifierDown = toggleEditingModifierDown(null);

            if (toggleEditingKey != null) {
                while (toggleEditingKey.method_1436()) {
                    if (!editingModifierDown || !ConfigManager.devEnvironmentAvailable()) continue;
                    ConfigManager.get().questEditing = !ConfigManager.get().questEditing;
                    ConfigManager.save();
                    if (client.field_1755 instanceof QuestBookScreen book) {
                        book.refreshEditingMode();
                    } else if (client.field_1755 instanceof QuestEditorScreen || client.field_1755 instanceof CategoryEditorScreen) {
                        client.method_1507(new QuestBookScreen(null));
                    }
                }
            }

            while (openKey.method_1436()) {
                if (editingModifierDown && ConfigManager.devEnvironmentAvailable()) continue;
                if (client.field_1724 != null) client.method_1507(new QuestBookScreen(null));
            }
        });
    }


    public static boolean handleEditingToggleKey(class_11908 event) {
        if (!ConfigManager.devEnvironmentAvailable() || toggleEditingKey == null || event == null) return false;
        if (!toggleEditingKey.method_1417(event) || !toggleEditingModifierDown(event)) return false;

        ConfigManager.get().questEditing = !ConfigManager.get().questEditing;
        ConfigManager.save();

        class_310 client = class_310.method_1551();
        if (client.field_1755 instanceof QuestBookScreen book) {
            book.refreshEditingMode();
        } else if (client.field_1755 instanceof QuestEditorScreen
                || client.field_1755 instanceof CategoryEditorScreen
                || client.field_1755 instanceof SearchSelectScreen) {
            client.method_1507(new QuestBookScreen(null));
        } else if (client.field_1755 instanceof FlintQuestConfigScreen configScreen) {
            configScreen.refreshEditingMode();
        }
        return true;
    }

    private static boolean toggleEditingModifierDown(class_11908 event) {
        if (toggleEditingModifierKey == null) return false;
        try {
            class_3675.class_306 key = class_3675.method_15981(toggleEditingModifierKey.method_1428());
            if (key.method_1442() == class_3675.class_307.field_1668) {
                if (class_3675.method_15987(class_310.method_1551().method_22683(), key.method_1444())) return true;
            }
        } catch (RuntimeException ignored) {
        }
        return toggleEditingModifierKey.method_1434() || (event != null && event.method_74240());
    }

    public static boolean linkNodesKeyDown() {
        return ConfigManager.devToolsEnabled() && linkNodesKey != null && linkNodesKey.method_1434();
    }

    public static boolean moveNodesKeyDown() {
        return ConfigManager.devToolsEnabled() && moveNodesKey != null && moveNodesKey.method_1434();
    }

    public static class_2561 linkNodesKeyName() {
        return linkNodesKey == null ? class_2561.method_43470("Link key") : linkNodesKey.method_16007();
    }

    public static class_2561 moveNodesKeyName() {
        return moveNodesKey == null ? class_2561.method_43470("Move key") : moveNodesKey.method_16007();
    }

    public static class_2561 toggleEditingKeyName() {
        return toggleEditingKey == null ? class_2561.method_43470("J") : toggleEditingKey.method_16007();
    }

    public static class_2561 toggleEditingModifierKeyName() {
        return toggleEditingModifierKey == null ? class_2561.method_43470("Left Control") : toggleEditingModifierKey.method_16007();
    }
}
