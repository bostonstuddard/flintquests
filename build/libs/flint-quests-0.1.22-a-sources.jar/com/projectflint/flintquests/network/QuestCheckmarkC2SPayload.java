package com.projectflint.flintquests.network;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record QuestCheckmarkC2SPayload(String questId, String taskId) implements class_8710 {
	public static final class_2960 PAYLOAD_ID = class_2960.method_60655("flintquests", "checkmark_task");
	public static final class_9154<QuestCheckmarkC2SPayload> ID = new class_9154<>(PAYLOAD_ID);
	public static final class_9139<class_9129, QuestCheckmarkC2SPayload> CODEC =
			class_9139.method_56435(
					class_9135.field_48554, QuestCheckmarkC2SPayload::questId,
					class_9135.field_48554, QuestCheckmarkC2SPayload::taskId,
					QuestCheckmarkC2SPayload::new
			);

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return ID;
	}
}
