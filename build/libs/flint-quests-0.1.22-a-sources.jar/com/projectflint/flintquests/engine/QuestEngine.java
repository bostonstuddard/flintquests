package com.projectflint.flintquests.engine;

import com.projectflint.flintquests.config.ConfigManager;
import com.projectflint.flintquests.data.CompletionMode;
import com.projectflint.flintquests.data.QuestDefinition;
import com.projectflint.flintquests.data.QuestRepository;
import com.projectflint.flintquests.data.QuestTask;
import com.projectflint.flintquests.data.TaskType;
import com.projectflint.flintquests.progress.PlayerQuestData;
import com.projectflint.flintquests.progress.ProgressManager;
import com.projectflint.flintquests.progress.QuestProgress;
import com.projectflint.flintquests.progress.TaskProgress;
import com.projectflint.flintquests.network.QuestNetworking;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import java.util.Map;

public final class QuestEngine {
    private static long ticks;

    private QuestEngine() {
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            ticks++;
            int interval = Math.max(1, ConfigManager.get().inventoryScanIntervalTicks);
            if (ticks % interval != 0) return;
            for (class_3222 player : server.method_3760().method_14571()) {
                scanInventory(player);
            }
        });

        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (world.method_8608() || !(player instanceof class_3222 serverPlayer)) return;
            String id = class_7923.field_41175.method_10221(state.method_26204()).toString();
            incrementMatching(serverPlayer, TaskType.BREAK_BLOCK, id, 1);
        });

        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (!world.method_8608() && player instanceof class_3222 serverPlayer) {
                class_1799 stack = player.method_5998(hand);
                String id = class_7923.field_41178.method_10221(stack.method_7909()).toString();
                incrementMatching(serverPlayer, TaskType.USE_ITEM, id, 1);
            }
            return class_1269.field_5811;
        });

        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (!world.method_8608() && player instanceof class_3222 serverPlayer) {
                String id = class_7923.field_41175.method_10221(world.method_8320(hitResult.method_17777()).method_26204()).toString();
                incrementMatching(serverPlayer, TaskType.INTERACT_BLOCK, id, 1);
            }
            return class_1269.field_5811;
        });
    }

    public static void scanInventory(class_3222 player) {
        PlayerQuestData data = ProgressManager.get(player);
        boolean changed = false;
        for (QuestDefinition quest : QuestRepository.all()) {
            if (isCompleted(data, quest.id) || !dependenciesSatisfied(data, quest)) continue;
            QuestProgress questProgress = data.quests.computeIfAbsent(quest.id, ignored -> new QuestProgress());
            for (QuestTask task : quest.tasks) {
                if (task.type != TaskType.OBTAIN_ITEM) continue;
                int amount = inventoryCount(player, task.target);
                TaskProgress progress = questProgress.tasks.computeIfAbsent(task.id, ignored -> new TaskProgress());
                int oldValue = progress.value;
                boolean oldComplete = progress.complete;
                progress.value = Math.min(amount, task.count);
                progress.complete = amount >= task.count;
                changed |= oldValue != progress.value || oldComplete != progress.complete;
            }
            changed |= tryComplete(player, data, quest, questProgress);
        }
        if (changed) {
            ProgressManager.save(player);
            QuestNetworking.sendProgress(player);
        }
    }

    public static void incrementCustomEvent(class_3222 player, String eventId, int amount) {
        incrementMatching(player, TaskType.CUSTOM_EVENT, eventId, amount);
    }

    public static boolean checkmark(class_3222 player, String questId) {
        PlayerQuestData data = ProgressManager.get(player);
        QuestDefinition quest = QuestRepository.get(questId);
        if (quest == null || !dependenciesSatisfied(data, quest)) return false;
        QuestProgress questProgress = data.quests.computeIfAbsent(quest.id, ignored -> new QuestProgress());
        boolean changed = false;
        for (QuestTask task : quest.tasks) {
            if (task.type != TaskType.CHECKMARK) continue;
            TaskProgress progress = questProgress.tasks.computeIfAbsent(task.id, ignored -> new TaskProgress());
            if (!progress.complete) changed = true;
            progress.value = 1;
            progress.complete = true;
        }
        tryComplete(player, data, quest, questProgress);
        if (changed) {
            ProgressManager.save(player);
            QuestNetworking.sendProgress(player);
        }
        return changed;
    }

    public static boolean checkmark(class_3222 player, String questId, String taskId) {
        PlayerQuestData data = ProgressManager.get(player);
        QuestDefinition quest = QuestRepository.get(questId);
        if (quest == null || !dependenciesSatisfied(data, quest)) return false;
        QuestTask task = quest.tasks.stream()
                .filter(candidate -> candidate.type == TaskType.CHECKMARK && candidate.id.equals(taskId))
                .findFirst()
                .orElse(null);
        if (task == null) return false;
        QuestProgress questProgress = data.quests.computeIfAbsent(quest.id, ignored -> new QuestProgress());
        TaskProgress progress = questProgress.tasks.computeIfAbsent(task.id, ignored -> new TaskProgress());
        if (progress.complete) return false;
        progress.value = 1;
        progress.complete = true;
        tryComplete(player, data, quest, questProgress);
        ProgressManager.save(player);
        QuestNetworking.sendProgress(player);
        return true;
    }

    public static boolean isCompleted(class_3222 player, String questId) {
        return isCompleted(ProgressManager.get(player), questId);
    }

    public static QuestProgress progress(class_3222 player, String questId) {
        return ProgressManager.get(player).quests.get(questId);
    }

    private static void incrementMatching(class_3222 player, TaskType type, String target, int amount) {
        if (amount <= 0) return;
        PlayerQuestData data = ProgressManager.get(player);
        boolean changed = false;
        for (QuestDefinition quest : QuestRepository.all()) {
            if (isCompleted(data, quest.id) || !dependenciesSatisfied(data, quest)) continue;
            QuestProgress questProgress = data.quests.computeIfAbsent(quest.id, ignored -> new QuestProgress());
            for (QuestTask task : quest.tasks) {
                if (task.type != type || !task.target.equals(target)) continue;
                TaskProgress progress = questProgress.tasks.computeIfAbsent(task.id, ignored -> new TaskProgress());
                int old = progress.value;
                progress.value = Math.min(task.count, progress.value + amount);
                progress.complete = progress.value >= task.count;
                changed |= old != progress.value;
            }
            changed |= tryComplete(player, data, quest, questProgress);
        }
        if (changed) {
            ProgressManager.save(player);
            QuestNetworking.sendProgress(player);
        }
    }

    private static boolean tryComplete(class_3222 player, PlayerQuestData data, QuestDefinition quest, QuestProgress questProgress) {
        if (questProgress.complete) return false;
        long requiredTasks = quest.tasks.stream().filter(task -> !task.optional).count();
        if (requiredTasks == 0) return false;

        boolean complete;
        if (quest.taskMode == CompletionMode.ANY) {
            complete = quest.tasks.stream()
                    .filter(task -> !task.optional)
                    .anyMatch(task -> taskComplete(questProgress, task));
        } else {
            complete = quest.tasks.stream()
                    .filter(task -> !task.optional)
                    .allMatch(task -> taskComplete(questProgress, task));
        }

        if (!complete) return false;
        questProgress.complete = true;
        questProgress.completedAt = System.currentTimeMillis();
        if (ConfigManager.get().announceQuestCompletion) {
            QuestNetworking.notifyCompleted(player, quest.id);
        }
        return true;
    }

    private static boolean taskComplete(QuestProgress questProgress, QuestTask task) {
        TaskProgress progress = questProgress.tasks.get(task.id);
        return progress != null && progress.complete;
    }

    private static boolean dependenciesSatisfied(PlayerQuestData data, QuestDefinition quest) {
        if (quest.dependencies.isEmpty()) return true;
        if (quest.dependencyMode == CompletionMode.ANY) {
            return quest.dependencies.stream().anyMatch(id -> isCompleted(data, id));
        }
        return quest.dependencies.stream().allMatch(id -> isCompleted(data, id));
    }

    private static boolean isCompleted(PlayerQuestData data, String questId) {
        QuestProgress progress = data.quests.get(questId);
        return progress != null && progress.complete;
    }

    private static int inventoryCount(class_3222 player, String target) {
        int count = 0;
        for (int slot = 0; slot < player.method_31548().method_5439(); slot++) {
            class_1799 stack = player.method_31548().method_5438(slot);
            if (stack.method_7960()) continue;
            if (class_7923.field_41178.method_10221(stack.method_7909()).toString().equals(target)) count += stack.method_7947();
        }
        return count;
    }
}
