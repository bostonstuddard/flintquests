package com.projectflint.flintquests.client;

import com.projectflint.flintquests.data.QuestDefinition;
import net.minecraft.class_161;
import net.minecraft.class_1799;
import net.minecraft.class_189;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_367;
import net.minecraft.class_8779;

public final class QuestCompletionNotifier {
    private QuestCompletionNotifier() {
    }

    public static void show(class_310 minecraft, QuestDefinition quest) {
        if (minecraft == null || quest == null) return;

        class_1799 icon = QuestIconHelper.stackFor(quest);
        class_2960 toastId = class_2960.method_60655("flintquests", "toast/" + safePath(quest.id));
        class_8779 advancement = class_161.class_162.method_707()
                .method_20416(
                        icon,
                        class_2561.method_43470(quest.title),
                        class_2561.method_43470("Flint Quest completed"),
                        null,
                        class_189.field_1250,
                        true,
                        false,
                        true
                )
                .method_695(toastId);

        minecraft.method_1566().method_1999(new class_367(advancement));
    }

    private static String safePath(String questId) {
        String value = questId == null ? "quest" : questId;
        int colon = value.indexOf(':');
        if (colon >= 0 && colon + 1 < value.length()) value = value.substring(colon + 1);
        value = value.toLowerCase().replaceAll("[^a-z0-9/._-]", "_");
        return value.isBlank() ? "quest" : value;
    }
}
