package com.projectflint.flintquests.client;

import com.projectflint.flintquests.data.CompletionMode;
import com.projectflint.flintquests.data.QuestDefinition;
import com.projectflint.flintquests.data.QuestRepository;
import com.projectflint.flintquests.data.QuestTask;
import com.projectflint.flintquests.data.TaskType;
import java.util.ArrayList;
import java.util.Arrays;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class QuestEditorScreen extends class_437 {
	private static final String QUEST_NAMESPACE = "flintquests:";

	private final class_437 parent;
	private final QuestDefinition original;
	private final QuestDefinition draft;

	private class_342 idPathBox;
	private class_342 titleBox;
	private class_342 descriptionBox;
	private class_342 chapterBox;
	private class_342 iconBox;
	private class_342 dependenciesBox;
	private class_342 xBox;
	private class_342 yBox;
	private class_342 taskIdBox;
	private class_342 taskLabelBox;
	private class_342 taskTargetBox;
	private class_342 taskCountBox;

	private int taskIndex;
	private TaskType currentTaskType = TaskType.OBTAIN_ITEM;
	private boolean currentTaskOptional;
	private class_4185 taskTypeButton;
	private class_4185 taskOptionalButton;
	private class_4185 targetSearchButton;
	private String saveError = "";

	public QuestEditorScreen(class_437 parent, QuestDefinition definition) {
		this(parent, definition, null);
	}

	public QuestEditorScreen(class_437 parent, QuestDefinition definition, String defaultCategory) {
		super(class_2561.method_43470(definition == null ? "Create Quest" : "Edit Quest"));
		this.parent = parent;
		this.original = definition;
		this.draft = definition == null ? new QuestDefinition() : copy(definition);
		if (definition == null && defaultCategory != null && !defaultCategory.isBlank()) {
			this.draft.chapter = defaultCategory.trim();
		}
		if (this.draft.tasks.isEmpty()) {
			this.draft.tasks.add(new QuestTask("task_0", TaskType.OBTAIN_ITEM, "Obtain a stick", "minecraft:stick", 1, false));
		}
	}

	@Override
	protected void method_25426() {
		EditorLayout layout = layout();
		int fieldHeight = 18;
		int namespaceWidth = Math.min(layout.fieldWidth() - 60, Math.max(78, field_22793.method_1727(QUEST_NAMESPACE) + 10));

		String idPath = draft.id == null ? "new_quest" : draft.id.substring(draft.id.indexOf(':') + 1);
		idPathBox = field(layout.left() + 12 + namespaceWidth, layout.row(0) + 11,
			layout.fieldWidth() - namespaceWidth, fieldHeight, idPath);

		titleBox = field(layout.left() + 12, layout.row(1) + 11, layout.fieldWidth(), fieldHeight, draft.title);
		descriptionBox = field(layout.left() + 12, layout.row(2) + 11, layout.fieldWidth(), fieldHeight, draft.description);
		chapterBox = field(layout.left() + 12, layout.row(3) + 11, layout.fieldWidth() - 66, fieldHeight, draft.chapter);
		iconBox = field(layout.left() + 12, layout.row(4) + 11, layout.fieldWidth() - 66, fieldHeight, draft.icon);
		dependenciesBox = field(layout.left() + 12, layout.row(5) + 11, layout.fieldWidth() - 66, fieldHeight, String.join(",", draft.dependencies));

		method_37063(class_4185.method_46430(class_2561.method_43470("Choose"), button -> chooseCategory())
				.method_46434(layout.left() + layout.panelWidth() - 66, layout.row(3) + 11, 54, fieldHeight).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Search"), button -> searchIcon())
				.method_46434(layout.left() + layout.panelWidth() - 66, layout.row(4) + 11, 54, fieldHeight).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Add"), button -> addDependency())
				.method_46434(layout.left() + layout.panelWidth() - 66, layout.row(5) + 11, 54, fieldHeight).method_46431());

		xBox = field(layout.left() + 12, layout.row(6) + 18, 64, fieldHeight, Integer.toString(draft.x));
		yBox = field(layout.left() + 86, layout.row(6) + 18, 64, fieldHeight, Integer.toString(draft.y));

		method_37063(class_4185.method_46430(class_2561.method_43470("Prerequisites: " + draft.dependencyMode), button -> {
			draft.dependencyMode = draft.dependencyMode == CompletionMode.ALL ? CompletionMode.ANY : CompletionMode.ALL;
			button.method_25355(class_2561.method_43470("Prerequisites: " + draft.dependencyMode));
		}).method_46434(layout.left() + 12, layout.row(7) + 8, layout.fieldWidth(), 18).method_46431());

		int half = (layout.fieldWidth() - 4) / 2;
		method_37063(class_4185.method_46430(class_2561.method_43470("Tasks: " + draft.taskMode), button -> {
			draft.taskMode = draft.taskMode == CompletionMode.ALL ? CompletionMode.ANY : CompletionMode.ALL;
			button.method_25355(class_2561.method_43470("Tasks: " + draft.taskMode));
		}).method_46434(layout.left() + 12, layout.row(8) + 5, half, 18).method_46431());

		method_37063(class_4185.method_46430(hiddenLabel(), button -> {
			draft.hiddenUntilDependencies = !draft.hiddenUntilDependencies;
			button.method_25355(hiddenLabel());
		}).method_46434(layout.left() + 16 + half, layout.row(8) + 5, half, 18).method_46431());

		taskIdBox = field(layout.right() + 12, layout.row(0) + 11, layout.fieldWidth(), fieldHeight, "");
		taskLabelBox = field(layout.right() + 12, layout.row(1) + 11, layout.fieldWidth(), fieldHeight, "");
		taskTypeButton = method_37063(class_4185.method_46430(class_2561.method_43473(), button -> cycleTaskType())
				.method_46434(layout.right() + 12, layout.row(2) + 11, layout.fieldWidth(), 18).method_46431());
		taskTargetBox = field(layout.right() + 12, layout.row(3) + 11, layout.fieldWidth() - 66, fieldHeight, "");
		targetSearchButton = method_37063(class_4185.method_46430(class_2561.method_43470("Search"), button -> searchTaskTarget())
				.method_46434(layout.right() + layout.panelWidth() - 66, layout.row(3) + 11, 54, fieldHeight).method_46431());
		taskCountBox = field(layout.right() + 12, layout.row(4) + 11, 64, fieldHeight, "1");
		taskOptionalButton = method_37063(class_4185.method_46430(class_2561.method_43473(), button -> {
			currentTaskOptional = !currentTaskOptional;
			updateTaskButtonLabels();
		}).method_46434(layout.right() + 86, layout.row(4) + 11, 96, 18).method_46431());

		int taskButtonWidth = (layout.fieldWidth() - 6) / 2;
		method_37063(class_4185.method_46430(class_2561.method_43470("< Previous"), button -> previousTask())
				.method_46434(layout.right() + 12, layout.row(6) + 8, taskButtonWidth, 18).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Next >"), button -> nextTask())
				.method_46434(layout.right() + 18 + taskButtonWidth, layout.row(6) + 8, taskButtonWidth, 18).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("+ Add task"), button -> addTask())
				.method_46434(layout.right() + 12, layout.row(7) + 8, taskButtonWidth, 18).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Delete task"), button -> removeTask())
				.method_46434(layout.right() + 18 + taskButtonWidth, layout.row(7) + 8, taskButtonWidth, 18).method_46431());

		int bottom = layout.bottomButtonY();
		method_37063(class_4185.method_46430(class_2561.method_43470("Save Quest"), button -> saveAndClose())
				.method_46434(field_22789 / 2 - 128, bottom, 92, 20).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), button -> method_25419())
				.method_46434(field_22789 / 2 - 30, bottom, 72, 20).method_46431());
		if (original != null) {
			method_37063(class_4185.method_46430(class_2561.method_43470("Delete Quest"), button -> deleteAndClose())
					.method_46434(field_22789 / 2 + 48, bottom, 92, 20).method_46431());
		}

		loadTaskFields();
	}

	private class_2561 hiddenLabel() {
		return class_2561.method_43470("Hide until ready: " + (draft.hiddenUntilDependencies ? "Yes" : "No"));
	}

	private class_342 field(int x, int y, int width, int height, String value) {
		class_342 box = new class_342(field_22793, x, y, width, height, class_2561.method_43473());
		box.method_1880(512);
		box.method_1852(value == null ? "" : value);
		method_37063(box);
		return box;
	}

	private void chooseCategory() {
		saveQuestFieldsToDraft();
		saveTaskFields();
		field_22787.method_1507(new SearchSelectScreen(this, class_2561.method_43470("Choose Quest Category"), SearchSelectScreen.Kind.CATEGORY,
				id -> draft.chapter = id));
	}

	private void searchIcon() {
		saveQuestFieldsToDraft();
		saveTaskFields();
		field_22787.method_1507(new SearchSelectScreen(this, class_2561.method_43470("Choose Quest Icon"), SearchSelectScreen.Kind.ITEM,
				id -> draft.icon = id));
	}

	private void addDependency() {
		saveQuestFieldsToDraft();
		saveTaskFields();
		field_22787.method_1507(new SearchSelectScreen(this, class_2561.method_43470("Add Quest Dependency"), SearchSelectScreen.Kind.QUEST,
				id -> {
					if (!id.equals(draft.id) && !draft.dependencies.contains(id)) draft.dependencies.add(id);
				}));
	}

	private void searchTaskTarget() {
		SearchSelectScreen.Kind kind = switch (currentTaskType) {
			case OBTAIN_ITEM, USE_ITEM -> SearchSelectScreen.Kind.ITEM;
			case BREAK_BLOCK, INTERACT_BLOCK -> SearchSelectScreen.Kind.BLOCK;
			default -> null;
		};
		if (kind == null) return;
		saveQuestFieldsToDraft();
		saveTaskFields();
		int selectedTask = taskIndex;
		field_22787.method_1507(new SearchSelectScreen(this, class_2561.method_43470("Choose Task Target"), kind,
				id -> draft.tasks.get(selectedTask).target = id));
	}

	private void cycleTaskType() {
		saveTaskFields();
		TaskType[] values = TaskType.values();
		currentTaskType = values[(currentTaskType.ordinal() + 1) % values.length];
		draft.tasks.get(taskIndex).type = currentTaskType;
		if (currentTaskType == TaskType.CHECKMARK) {
			taskTargetBox.method_1852("");
			taskCountBox.method_1852("1");
		}
		updateTaskButtonLabels();
	}

	private void previousTask() {
		saveTaskFields();
		if (taskIndex > 0) taskIndex--;
		loadTaskFields();
	}

	private void nextTask() {
		saveTaskFields();
		if (taskIndex < draft.tasks.size() - 1) taskIndex++;
		loadTaskFields();
	}

	private void addTask() {
		saveTaskFields();
		draft.tasks.add(new QuestTask("task_" + draft.tasks.size(), TaskType.OBTAIN_ITEM, "", "minecraft:stick", 1, false));
		taskIndex = draft.tasks.size() - 1;
		loadTaskFields();
	}

	private void removeTask() {
		if (draft.tasks.size() <= 1) return;
		draft.tasks.remove(taskIndex);
		taskIndex = Math.max(0, Math.min(taskIndex, draft.tasks.size() - 1));
		loadTaskFields();
	}

	private void loadTaskFields() {
		QuestTask task = draft.tasks.get(taskIndex);
		currentTaskType = task.type;
		currentTaskOptional = task.optional;
		taskIdBox.method_1852(task.id);
		taskLabelBox.method_1852(task.label == null ? "" : task.label);
		taskTargetBox.method_1852(task.target);
		taskCountBox.method_1852(Integer.toString(task.count));
		updateTaskButtonLabels();
	}

	private void updateTaskButtonLabels() {
		if (taskTypeButton != null) taskTypeButton.method_25355(class_2561.method_43470("Completion condition: " + friendlyTaskType(currentTaskType)));
		if (taskOptionalButton != null) taskOptionalButton.method_25355(class_2561.method_43470(currentTaskOptional ? "Optional" : "Required"));
		boolean searchableTarget = currentTaskType == TaskType.OBTAIN_ITEM || currentTaskType == TaskType.USE_ITEM
				|| currentTaskType == TaskType.BREAK_BLOCK || currentTaskType == TaskType.INTERACT_BLOCK;
		boolean hasTarget = currentTaskType != TaskType.CHECKMARK;
		if (targetSearchButton != null) targetSearchButton.field_22763 = searchableTarget;
		if (taskTargetBox != null) taskTargetBox.field_22763 = hasTarget;
		if (taskCountBox != null) taskCountBox.field_22763 = hasTarget;
	}

	private String friendlyTaskType(TaskType type) {
		return switch (type) {
			case OBTAIN_ITEM -> "Obtain Item";
			case BREAK_BLOCK -> "Break Block";
			case USE_ITEM -> "Use Item";
			case INTERACT_BLOCK -> "Interact With Block";
			case CUSTOM_EVENT -> "Flint/Custom Event";
			case CHECKMARK -> "Manual Checkmark";
		};
	}

	private void saveTaskFields() {
		if (draft.tasks.isEmpty()) return;
		QuestTask task = draft.tasks.get(taskIndex);
		task.id = taskIdBox.method_1882().trim();
		task.type = currentTaskType;
		task.label = taskLabelBox.method_1882().trim();
		task.target = taskTargetBox.method_1882().trim();
		task.count = parseInt(taskCountBox.method_1882(), 1);
		task.optional = currentTaskOptional;
		task.normalize(taskIndex);
	}

	private void saveQuestFieldsToDraft() {
		if (idPathBox != null) {
			String path = QuestDefinition.normalizeIdPath(idPathBox.method_1882());
			draft.id = QUEST_NAMESPACE + (path.isBlank() ? "new_quest" : path);
		}
		draft.title = titleBox.method_1882().trim();
		draft.description = descriptionBox.method_1882().trim();
		draft.chapter = chapterBox.method_1882().trim();
		draft.icon = iconBox.method_1882().trim();
		draft.x = parseInt(xBox.method_1882(), 0);
		draft.y = parseInt(yBox.method_1882(), 0);
		draft.dependencies = new ArrayList<>();
		Arrays.stream(dependenciesBox.method_1882().split(","))
				.map(String::trim)
				.filter(value -> !value.isBlank())
				.filter(value -> !value.equals(draft.id))
				.forEach(draft.dependencies::add);
	}

	private void saveAndClose() {
		saveError = "";
		saveTaskFields();
		saveQuestFieldsToDraft();
		draft.normalize();

		String previousId = original == null ? "" : original.id;
		QuestDefinition collision = QuestRepository.get(draft.id);
		if (collision != null && !collision.id.equals(previousId)) {
			saveError = "That quest ID is already in use.";
			return;
		}

		try {
			if (original == null) QuestRepository.save(draft);
			else QuestRepository.saveRenamed(previousId, draft);
			QuestRepository.load();
			field_22787.method_1507(parent);
		} catch (IllegalArgumentException exception) {
			saveError = exception.getMessage();
		}
	}

	private void deleteAndClose() {
		if (original != null) QuestRepository.delete(original.id);
		QuestRepository.load();
		field_22787.method_1507(parent);
	}

	private int parseInt(String text, int fallback) {
		try {
			return Integer.parseInt(text.trim());
		} catch (NumberFormatException ignored) {
			return fallback;
		}
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
		EditorLayout layout = layout();
		int namespaceWidth = Math.min(layout.fieldWidth() - 60, Math.max(78, field_22793.method_1727(QUEST_NAMESPACE) + 10));

		graphics.method_25294(0, 0, field_22789, field_22790, 0xC818202A);
		graphics.method_25294(layout.left(), 4, layout.left() + layout.panelWidth(), layout.panelBottom(), 0xF0232D39);
		graphics.method_25294(layout.right(), 4, layout.right() + layout.panelWidth(), layout.panelBottom(), 0xF0232D39);

		graphics.method_51439(field_22793, class_2561.method_43470("QUEST"), layout.left() + 12, 10, 0xFFFFD46A, false);
		graphics.method_51439(field_22793, class_2561.method_43470("TASK " + (taskIndex + 1) + " / " + draft.tasks.size()), layout.right() + 12, 10, 0xFFFFD46A, false);

		label(graphics, "Quest ID", layout.left() + 12, layout.row(0));
		graphics.method_25294(layout.left() + 12, layout.row(0) + 11, layout.left() + 12 + namespaceWidth, layout.row(0) + 29, 0xFF10161D);
		graphics.method_51439(field_22793, class_2561.method_43470(QUEST_NAMESPACE), layout.left() + 17, layout.row(0) + 16, 0xFF8FA0B2, false);

		label(graphics, "Title shown to players", layout.left() + 12, layout.row(1));
		label(graphics, "Description / instructions", layout.left() + 12, layout.row(2));
		label(graphics, "Category", layout.left() + 12, layout.row(3));
		label(graphics, "Quest icon", layout.left() + 12, layout.row(4));
		label(graphics, "Prerequisite quests", layout.left() + 12, layout.row(5));
		label(graphics, "Canvas node position", layout.left() + 12, layout.row(6));
		graphics.method_51439(field_22793, class_2561.method_43470("X"), layout.left() + 12, layout.row(6) + 10, 0xFF8FA0B2, false);
		graphics.method_51439(field_22793, class_2561.method_43470("Y"), layout.left() + 86, layout.row(6) + 10, 0xFF8FA0B2, false);

		label(graphics, "Internal task ID", layout.right() + 12, layout.row(0));
		label(graphics, "Task text shown to players", layout.right() + 12, layout.row(1));
		label(graphics, "Completion condition", layout.right() + 12, layout.row(2));
		String targetLabel = currentTaskType == TaskType.CHECKMARK
				? "Manual Checkmark: no target needed"
				: switch (currentTaskType) {
					case OBTAIN_ITEM, USE_ITEM -> "Target item";
					case BREAK_BLOCK, INTERACT_BLOCK -> "Target block";
					case CUSTOM_EVENT -> "Custom API event ID";
					case CHECKMARK -> "Manual Checkmark: no target needed";
				};
		label(graphics, targetLabel, layout.right() + 12, layout.row(3));
		label(graphics, currentTaskType == TaskType.CHECKMARK ? "Count fixed at 1" : "Required count", layout.right() + 12, layout.row(4));

		if (!saveError.isBlank()) {
			graphics.method_27534(field_22793, class_2561.method_43470(saveError), field_22789 / 2, layout.bottomButtonY() - 11, 0xFFFF6B6B);
		}

		super.method_25394(graphics, mouseX, mouseY, partialTick);
	}

	private EditorLayout layout() {
		int gap = 14;
		int panelWidth = Math.min(330, Math.max(180, (field_22789 - gap * 3) / 2));
		int left = field_22789 / 2 - panelWidth - gap / 2;
		int right = field_22789 / 2 + gap / 2;
		int fieldWidth = panelWidth - 24;
		int contentTop = 25;
		int bottomButtonY = Math.max(0, field_22790 - 25);
		int maxStepForHeight = Math.max(28, (bottomButtonY - 24 - contentTop) / 8);
		int rowStep = Math.min(34, maxStepForHeight);
		int panelBottom = Math.max(4, bottomButtonY - 6);
		return new EditorLayout(panelWidth, left, right, fieldWidth, contentTop, rowStep, bottomButtonY, panelBottom);
	}

	private void label(class_332 graphics, String text, int x, int y) {
		graphics.method_51439(field_22793, class_2561.method_43470(text), x, y, 0xFFB7C1CC, false);
	}

	private record EditorLayout(int panelWidth, int left, int right, int fieldWidth, int contentTop,
			int rowStep, int bottomButtonY, int panelBottom) {
		int row(int index) {
			return contentTop + index * rowStep;
		}
	}

	@Override
	public void method_25419() {
		field_22787.method_1507(parent);
	}

	private static QuestDefinition copy(QuestDefinition source) {
		QuestDefinition copy = new QuestDefinition();
		copy.id = source.id;
		copy.chapter = source.chapter;
		copy.title = source.title;
		copy.description = source.description;
		copy.icon = source.icon;
		copy.x = source.x;
		copy.y = source.y;
		copy.hiddenUntilDependencies = source.hiddenUntilDependencies;
		copy.dependencyMode = source.dependencyMode;
		copy.taskMode = source.taskMode;
		copy.dependencies = new ArrayList<>(source.dependencies);
		copy.tasks = new ArrayList<>();
		for (QuestTask task : source.tasks) {
			copy.tasks.add(new QuestTask(task.id, task.type, task.label, task.target, task.count, task.optional));
		}
		return copy;
	}
}
