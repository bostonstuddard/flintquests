package com.projectflint.flintquests.client;

import com.projectflint.flintquests.data.CategoryRepository;
import com.projectflint.flintquests.data.QuestCategoryDefinition;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class CategoryEditorScreen extends class_437 {
    private final class_437 parent;
    private final QuestCategoryDefinition original;
    private final QuestCategoryDefinition draft;

    private class_342 idBox;
    private class_342 titleBox;
    private class_342 iconBox;
    private class_342 parentBox;
    private class_342 orderBox;

    public CategoryEditorScreen(class_437 parent, QuestCategoryDefinition category) {
        super(class_2561.method_43470(category == null ? "Create Quest Category" : "Edit Quest Category"));
        this.parent = parent;
        this.original = category == null ? null : category.copy();
        this.draft = category == null ? new QuestCategoryDefinition() : category.copy();
        if (category == null) {
            draft.id = "new_category";
            draft.title = "New Category";
            draft.icon = "minecraft:book";
            draft.parent = "";
        }
    }

    @Override
    protected void method_25426() {
        int panelWidth = Math.min(380, field_22789 - 60);
        int left = field_22789 / 2 - panelWidth / 2;
        int fieldWidth = panelWidth - 24;
        int top = Math.max(38, field_22790 / 2 - 110);

        if (original == null) {
            idBox = field(left + 12, top + 28, fieldWidth, 18, draft.id);
        }
        titleBox = field(left + 12, top + 66, fieldWidth, 18, draft.title);
        iconBox = field(left + 12, top + 104, fieldWidth - 66, 18, draft.icon);
        parentBox = field(left + 12, top + 142, fieldWidth - 66, 18, draft.parent);
        orderBox = field(left + 12, top + 180, 72, 18, Integer.toString(draft.order));

        method_37063(class_4185.method_46430(class_2561.method_43470("Search"), button -> {
                saveFieldsToDraft();
                field_22787.method_1507(new SearchSelectScreen(this, class_2561.method_43470("Choose Category Icon"), SearchSelectScreen.Kind.ITEM,
                        id -> draft.icon = id));
            })
                .method_46434(left + panelWidth - 66, top + 104, 54, 18).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Choose"), button -> {
                saveFieldsToDraft();
                field_22787.method_1507(new SearchSelectScreen(this, class_2561.method_43470("Choose Parent Category"), SearchSelectScreen.Kind.CATEGORY,
                        id -> draft.parent = id));
            })
                .method_46434(left + panelWidth - 66, top + 142, 54, 18).method_46431());

        int bottom = field_22790 - 30;
        method_37063(class_4185.method_46430(class_2561.method_43470("Save Category"), button -> saveAndClose())
                .method_46434(field_22789 / 2 - 104, bottom, 98, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), button -> method_25419())
                .method_46434(field_22789 / 2 + 6, bottom, 72, 20).method_46431());
    }

    private class_342 field(int x, int y, int width, int height, String value) {
        class_342 box = new class_342(field_22793, x, y, width, height, class_2561.method_43473());
        box.method_1880(256);
        box.method_1852(value == null ? "" : value);
        method_37063(box);
        return box;
    }

    private void saveFieldsToDraft() {
        if (original == null && idBox != null) draft.id = idBox.method_1882().trim();
        else if (original != null) draft.id = original.id;
        draft.title = titleBox.method_1882().trim();
        draft.icon = iconBox.method_1882().trim();
        draft.parent = parentBox.method_1882().trim();
        draft.order = parseInt(orderBox.method_1882(), 0);
    }

    private void saveAndClose() {
        saveFieldsToDraft();
        if (draft.parent.equals(draft.id)) draft.parent = "";
        draft.normalize();
        CategoryRepository.save(draft);
        CategoryRepository.load();
        field_22787.method_1507(parent);
    }

    private int parseInt(String text, int fallback) {
        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        int panelWidth = Math.min(380, field_22789 - 60);
        int left = field_22789 / 2 - panelWidth / 2;
        int top = Math.max(38, field_22790 / 2 - 110);
        graphics.method_25294(0, 0, field_22789, field_22790, 0xB818202A);
        graphics.method_25294(left, top - 18, left + panelWidth, top + 216, 0xF0232D39);
        graphics.method_27534(field_22793, field_22785, field_22789 / 2, top - 10, 0xFFF3F5F7);

        if (original == null) label(graphics, "Category ID", left + 12, top + 16);
        else label(graphics, "Category ID (locked): " + original.id, left + 12, top + 20);
        label(graphics, "Display name", left + 12, top + 54);
        label(graphics, "Icon item", left + 12, top + 92);
        label(graphics, "Parent category (blank = top level)", left + 12, top + 130);
        label(graphics, "Sort order", left + 12, top + 168);
        graphics.method_51439(field_22793, class_2561.method_43470("Use Search/Choose instead of memorizing registry IDs."), left + 12, top + 206, 0xFF8FA0B2, false);
        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    private void label(class_332 graphics, String text, int x, int y) {
        graphics.method_51439(field_22793, class_2561.method_43470(text), x, y, 0xFFB7C1CC, false);
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }
}
