package com.projectflint.flintquests.client;

import com.projectflint.flintquests.data.QuestDefinition;
import com.projectflint.flintquests.data.QuestRepository;
import com.projectflint.flintquests.network.QuestCompletedS2CPayload;
import com.projectflint.flintquests.network.QuestProgressS2CPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class FlintQuestsClient implements ClientModInitializer {
    private static class_304 openKey;

    @Override
    public void onInitializeClient() {
        openKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.flintquests.open",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_J,
                class_304.class_11900.field_62556
        ));

        ClientPlayNetworking.registerGlobalReceiver(QuestProgressS2CPayload.ID, (payload, context) ->
                context.client().execute(() -> {
                    ClientQuestProgress.applyJson(payload.json());
                    if (context.client().field_1755 instanceof QuestBookScreen book) book.refreshFromProgress();
                    if (context.client().field_1755 instanceof QuestDetailScreen detail) detail.refreshFromProgress();
                }));

        ClientPlayNetworking.registerGlobalReceiver(QuestCompletedS2CPayload.ID, (payload, context) ->
                context.client().execute(() -> {
                    ClientQuestProgress.markQuestComplete(payload.questId());
                    QuestDefinition quest = QuestRepository.get(payload.questId());
                    if (quest != null) QuestCompletionNotifier.show(context.client(), quest);
                    if (context.client().field_1755 instanceof QuestBookScreen book) book.refreshFromProgress();
                    if (context.client().field_1755 instanceof QuestDetailScreen detail) detail.refreshFromProgress();
                }));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.method_1436()) {
                if (client.field_1724 != null) client.method_1507(new QuestBookScreen(null));
            }
        });
    }
}
