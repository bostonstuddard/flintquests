package com.projectflint.flintquests.client;

import com.projectflint.flintquests.data.CategoryRepository;
import com.projectflint.flintquests.data.QuestCategoryDefinition;
import com.projectflint.flintquests.data.QuestDefinition;
import com.projectflint.flintquests.data.QuestTask;
import com.projectflint.flintquests.data.TaskType;
import com.projectflint.flintquests.network.QuestCheckmarkC2SPayload;
import com.projectflint.flintquests.network.QuestProgressRequestC2SPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.LinkedHashMap;
import java.util.Map;

public final class QuestDetailScreen extends class_437 {
	private final class_437 parent;
	private final QuestDefinition quest;
	private final Map<String, class_4185> checkmarkButtons = new LinkedHashMap<>();

	public QuestDetailScreen(class_437 parent, QuestDefinition quest) {
		super(class_2561.method_43470(quest.title));
		this.parent = parent;
		this.quest = quest;
	}

	@Override
	protected void method_25426() {
		checkmarkButtons.clear();

		int panelWidth = Math.min(430, field_22789 - 40);
		int panelHeight = Math.min(300, field_22790 - 44);
		int left = field_22789 / 2 - panelWidth / 2;
		int top = field_22790 / 2 - panelHeight / 2 - 4;
		int taskY = top + 112;

		for (QuestTask task : quest.tasks) {
			if (taskY > top + panelHeight - 54) break;
			if (task.type == TaskType.CHECKMARK) {
				boolean complete = ClientQuestProgress.taskComplete(quest.id, task.id);
				class_4185 check = class_4185.method_46430(checkmarkLabel(task, complete), button -> submitCheckmark(task, button))
						.method_46434(left + 22, taskY - 3, panelWidth - 44, 20)
						.method_46431();
				check.field_22763 = !complete && !ClientQuestProgress.questComplete(quest.id);
				method_37063(check);
				checkmarkButtons.put(task.id, check);
				taskY += 26;
			} else {
				taskY += 18;
			}
		}

		method_37063(class_4185.method_46430(class_2561.method_43470("Back"), button -> method_25419())
				.method_46434(field_22789 / 2 - 40, field_22790 - 34, 80, 20).method_46431());

		if (field_22787 != null && field_22787.field_1724 != null) {
			ClientPlayNetworking.send(new QuestProgressRequestC2SPayload("quest_detail_open"));
		}
	}

	public void refreshFromProgress() {
		for (QuestTask task : quest.tasks) {
			if (task.type != TaskType.CHECKMARK) continue;
			class_4185 button = checkmarkButtons.get(task.id);
			if (button == null) continue;
			boolean complete = ClientQuestProgress.taskComplete(quest.id, task.id);
			button.method_25355(checkmarkLabel(task, complete));
			button.field_22763 = !complete && !ClientQuestProgress.questComplete(quest.id);
		}
	}

	private class_2561 checkmarkLabel(QuestTask task, boolean complete) {
		return class_2561.method_43470((complete ? "[✓]  " : "[ ]  ") + task.displayLabel());
	}

	private void submitCheckmark(QuestTask task, class_4185 button) {
		if (field_22787.field_1724 == null || ClientQuestProgress.taskComplete(quest.id, task.id)) return;
		ClientPlayNetworking.send(new QuestCheckmarkC2SPayload(quest.id, task.id));
		button.field_22763 = false;
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
		int panelWidth = Math.min(430, field_22789 - 40);
		int panelHeight = Math.min(300, field_22790 - 44);
		int left = field_22789 / 2 - panelWidth / 2;
		int top = field_22790 / 2 - panelHeight / 2 - 4;
		boolean questComplete = ClientQuestProgress.questComplete(quest.id);

		graphics.method_25294(0, 0, field_22789, field_22790, 0xB818202A);
		graphics.method_25294(left, top, left + panelWidth, top + panelHeight, 0xF0232D39);
		graphics.method_25294(left, top, left + panelWidth, top + 1, questComplete ? 0xFF72FF63 : 0xFF748196);
		graphics.method_25294(left, top + panelHeight - 1, left + panelWidth, top + panelHeight, 0xFF111820);

		graphics.method_51427(QuestIconHelper.stackFor(quest), left + 18, top + 18);
		graphics.method_51439(field_22793, field_22785, left + 44, top + 18, 0xFFF3F5F7, false);
		QuestCategoryDefinition category = CategoryRepository.get(quest.chapter);
		String categoryName = category == null ? quest.chapter : category.title;
		graphics.method_51439(field_22793, class_2561.method_43470(categoryName), left + 44, top + 31, 0xFF8FA0B2, false);

		if (questComplete) {
			graphics.method_51439(field_22793, class_2561.method_43470("✓ COMPLETED"), left + panelWidth - 86, top + 20, 0xFF72FF63, false);
		}

		int textY = top + 56;
		graphics.method_51439(field_22793, class_2561.method_43470(quest.description), left + 18, textY, 0xFFD5DCE5, false);
		textY += 36;
		graphics.method_51439(field_22793, class_2561.method_43470("Tasks"), left + 18, textY, 0xFFFFD46A, false);
		textY += 18;

		for (QuestTask task : quest.tasks) {
			if (textY > top + panelHeight - 48) break;
			if (task.type == TaskType.CHECKMARK) {
				textY += 26;
				continue;
			}

			boolean complete = ClientQuestProgress.taskComplete(quest.id, task.id);
			String state = complete ? "✓ " : "• ";
			String suffix = task.count > 1 ? "  x" + task.count : "";
			String optional = task.optional ? "  (optional)" : "";
			int color = complete ? 0xFF72FF63 : 0xFFE6EAF0;
			graphics.method_51439(field_22793, class_2561.method_43470(state + task.displayLabel() + suffix + optional), left + 24, textY, color, false);
			textY += 18;
		}

		super.method_25394(graphics, mouseX, mouseY, partialTick);
	}

	@Override
	public void method_25419() {
		field_22787.method_1507(parent);
	}
}
