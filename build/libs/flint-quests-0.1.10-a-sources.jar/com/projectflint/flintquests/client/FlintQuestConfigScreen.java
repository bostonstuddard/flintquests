package com.projectflint.flintquests.client;

import com.projectflint.flintquests.config.ConfigManager;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Lightweight settings screen used by the optional Mod Menu integration.
 * It intentionally avoids calling renderBackground(...) directly because
 * Minecraft 1.21.11 already performs the screen blur/background pass.
 */
public final class FlintQuestConfigScreen extends class_437 {
    private final class_437 parent;

    public FlintQuestConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Flint Quests Settings"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        ConfigManager.load();

        int center = field_22789 / 2;
        int top = Math.max(64, field_22790 / 2 - 48);
        int buttonWidth = 240;
        int left = center - buttonWidth / 2;

        method_37063(class_4185.method_46430(editingLabel(), button -> {
            ConfigManager.get().questEditing = !ConfigManager.get().questEditing;
            ConfigManager.save();
            button.method_25355(editingLabel());
        }).method_46434(left, top, buttonWidth, 20).method_46431());

        method_37063(class_4185.method_46430(announceLabel(), button -> {
            ConfigManager.get().announceQuestCompletion = !ConfigManager.get().announceQuestCompletion;
            ConfigManager.save();
            button.method_25355(announceLabel());
        }).method_46434(left, top + 28, buttonWidth, 20).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43470("Done"), button -> method_25419())
                .method_46434(center - 50, top + 72, 100, 20).method_46431());
    }

    private class_2561 editingLabel() {
        return class_2561.method_43470("Quest Editing: " + enabled(ConfigManager.get().questEditing));
    }

    private class_2561 announceLabel() {
        return class_2561.method_43470("Quest Completion Popups: " + enabled(ConfigManager.get().announceQuestCompletion));
    }

    private String enabled(boolean value) {
        return value ? "ON" : "OFF";
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        graphics.method_27534(field_22793, field_22785, field_22789 / 2, 24, 0xFFFFFF);
        graphics.method_27534(field_22793,
                class_2561.method_43470("Settings save immediately"),
                field_22789 / 2, 40, 0xA0A0A0);
        graphics.method_27534(field_22793,
                class_2561.method_43470("Editing OFF = player/read-only quest mode"),
                field_22789 / 2, 50, 0x808080);
        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }
}
